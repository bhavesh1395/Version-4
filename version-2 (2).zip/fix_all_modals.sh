#!/bin/bash
sed -i 's/initial={{ opacity: 0, scale: 0.9 }}/initial={{ opacity: 0, scale: 0.95 }}/g' shiksha/components/Lanterns.tsx
sed -i 's/exit={{ opacity: 0, scale: 0.9 }}/exit={{ opacity: 0, scale: 0.95 }}/g' shiksha/components/Lanterns.tsx
sed -i 's/transition={{ duration: 0.15, ease: "easeOut" }}/transition={{ duration: 0.1, ease: "easeOut" }}/g' shiksha/components/Lanterns.tsx

sed -i 's/initial={{ opacity: 0, scale: 0.9 }}/initial={{ opacity: 0, scale: 0.95 }}/g' shiksha/components/MemoryTree.tsx
sed -i 's/exit={{ opacity: 0, scale: 0.9 }}/exit={{ opacity: 0, scale: 0.95 }}/g' shiksha/components/MemoryTree.tsx
sed -i 's/transition={{ duration: 0.15, ease: "easeOut" }}/transition={{ duration: 0.1, ease: "easeOut" }}/g' shiksha/components/MemoryTree.tsx

sed -i 's/initial={{ scale: 0.9, y: 20 }}/initial={{ scale: 0.95, y: 10 }}/g' shiksha/components/Constellation.tsx
sed -i 's/exit={{ scale: 0.9, y: 20 }}/exit={{ scale: 0.95, y: 10 }}/g' shiksha/components/Constellation.tsx
sed -i 's/transition={{ duration: 0.15, ease: "easeOut" }}/transition={{ duration: 0.1, ease: "easeOut" }}/g' shiksha/components/Constellation.tsx

sed -i 's/initial={{ scale: 0.9, y: 20 }}/initial={{ scale: 0.95, y: 10 }}/g' shiksha/components/Garden.tsx
sed -i 's/exit={{ scale: 0.9, y: 20 }}/exit={{ scale: 0.95, y: 10 }}/g' shiksha/components/Garden.tsx
sed -i 's/transition={{ duration: 0.15, ease: "easeOut" }}/transition={{ duration: 0.1, ease: "easeOut" }}/g' shiksha/components/Garden.tsx

sed -i 's/transition={{ duration: 0.2, ease: "easeOut" }}/transition={{ duration: 0.15, ease: "easeOut" }}/g' shiksha/App.tsx
