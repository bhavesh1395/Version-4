#!/bin/bash
awk '
NR >= 78 && NR <= 87 { next }
NR == 77 {
  print "    // Chrome/Safari voice lazy loading guard"
  print "    try {"
  print "      if (window.speechSynthesis.getVoices().length > 0) {"
  print "        loadVoicesAndSpeak();"
  print "      } else {"
  print "        window.speechSynthesis.onvoiceschanged = loadVoicesAndSpeak;"
  print "      }"
  print "    } catch(e) {}"
  print "    return () => {"
  print "      try { window.speechSynthesis.cancel(); } catch (e) {}"
  print "    };"
  next
}
{ print }
' shiksha/components/ApologyLetter.tsx > temp.tsx
mv temp.tsx shiksha/components/ApologyLetter.tsx
