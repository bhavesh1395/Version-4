#!/bin/bash
awk '
/user-select:/ { next }
/-webkit-user-select:/ { next }
/^\* {/ { next }
/^}input,/ { next }
/^input, textarea, select {/ { next }
/!important/ { next }
{ print }
' shiksha/index.css > temp2.css

cat << 'INNEREOF' >> temp2.css

* {
  user-select: none !important;
  -webkit-user-select: none !important;
}

input, textarea, select {
  user-select: auto !important;
  -webkit-user-select: auto !important;
}
INNEREOF

mv temp2.css shiksha/index.css
