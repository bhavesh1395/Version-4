#!/bin/bash
sed -i 's/try { if (window.speechSynthesis.getVoices().length > 0) {/try { if (window.speechSynthesis.getVoices().length > 0) {/g' shiksha/components/ApologyLetter.tsx
sed -i 's/window.speechSynthesis.onvoiceschanged = loadVoicesAndSpeak; } catch(e) {}/window.speechSynthesis.onvoiceschanged = loadVoicesAndSpeak;/g' shiksha/components/ApologyLetter.tsx
sed -i 's/    }    return () => {/    } } catch(e) {}    return () => {/g' shiksha/components/ApologyLetter.tsx
