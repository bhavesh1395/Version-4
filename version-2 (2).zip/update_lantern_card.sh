#!/bin/bash
awk '
/\{mediaUrl && \(/ { skip = 1; print "        {mediaUrl ? ("; print "          <div className=\"w-10 h-10 rounded-lg overflow-hidden mb-2 z-10 border border-white/50 shadow-[0_0_10px_rgba(255,255,255,0.3)]\">"; print "            <img src={mediaUrl} className=\"w-full h-full object-cover\" alt=\"thumbnail\" />"; print "          </div>"; print "        ) : ("; print "          <Camera size={28} className=\"text-white mb-2 z-10\" strokeWidth={1.5}  />"; print "        )}"; next }
skip && /<Camera size=\{28\} className=\"text-white mb-2 z-10\" strokeWidth=\{1.5\}  \/>/ { skip = 0; next }
skip { next }
{ print }
' shiksha/components/Lanterns.tsx > temp.tsx
mv temp.tsx shiksha/components/Lanterns.tsx
