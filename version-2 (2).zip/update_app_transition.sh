#!/bin/bash
sed -i 's/transition={{ duration: 0.8 }}/transition={{ duration: 0.3 }}/g' shiksha/App.tsx
