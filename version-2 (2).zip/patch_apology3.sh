#!/bin/bash
cat << 'INNER' > shiksha/components/ApologyLetter.tsx
import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'react';
import { Heart, Play, Pause, Loader2 } from 'lucide-react';
import { motion as motion_react } from 'motion/react';

// just to be safe, I will fix the import
INNER
