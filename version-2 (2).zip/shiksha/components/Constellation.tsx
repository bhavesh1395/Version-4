import React, { useState, useRef, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Camera, Calendar, Check, Edit2, RotateCcw } from 'lucide-react';
import { usePersistentState } from '../lib/usePersistentState';
import { MediaUpload } from './MediaUpload';

// Spatially infinite star generator helper
const NEON_COLORS = [
  '#ff007f', '#00e5ff', '#39ff14', '#8a2be2', '#ffff00', '#ff5e00'
];

const createStarAt = (id: number, offsetDays: number, xCoordinate: number) => {
  const date = new Date(Date.now() - offsetDays * 24 * 60 * 60 * 1000);
  const color = NEON_COLORS[Math.floor(Math.random() * NEON_COLORS.length)];
  return {
    id,
    x: xCoordinate,
    y: Math.random() * 60 - 30, // vertical offset percentage
    size: Math.random() * 3 + 1.5,
    memory: "", // strictly empty initial notes as requested
    date: date.toISOString().split('T')[0],
    mediaUrl: null as string | null,
    mediaFile: null as Blob | null,
    mediaType: null as string | null,
    mediaName: null as string | null, 
    color
  };
};

const generateInitialStars = () => {
  const generated = [];
  // Spacing stars across the initial X range
  for (let i = 0; i < 40; i++) {
    generated.push(createStarAt(i + 1, i * 4 + Math.random() * 3, -i * 120 + 200));
  }
  return generated; // sorted from newest (right-most/center X) to oldest (left-most X)
};

export function Constellation() {
  const [stars, setStars, isLoadedStars] = usePersistentState('constellation_stars', generateInitialStars);
  const [activeStar, setActiveStar, isLoadedActive] = usePersistentState<number | null>('constellation_active', null);
  const [persistentPan, setPersistentPan, isLoadedPan] = usePersistentState('constellation_pan', { x: 0, y: 0 });
  const panRef = useRef({ x: 0, y: 0 });
  const panContainerRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (isLoadedPan) {
      panRef.current = { ...persistentPan };
      if (panContainerRef.current) {
        panContainerRef.current.style.transform = `translateX(${persistentPan.x}px)`;
      }
    }
  }, [isLoadedPan]);
  const [isPanning, setIsPanning] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const lastPos = useRef({ x: 0, y: 0 });

  const [searchDate, setSearchDate] = useState('');
  const [highlightId, setHighlightId] = useState<number | null>(null);

  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState("");
  const [editDate, setEditDate] = useState("");
  
  useEffect(() => {
    if (activeStar !== null) {
      const star = stars.find(s => s.id === activeStar);
      if (star) {
        setEditValue(star.memory || "");
        setEditDate(star.date || "");
      }
    }
  }, [activeStar]);

  // Sync with cache removed
  useEffect(() => {
    // INFINITE SCROLL TRIGGER
    // If the user scrolls far to the left (panning right, moving older stars in), 
    // detect if we are close to the oldest star's X coordinate and generate more!
    const oldestStar = stars[stars.length - 1];
    if (oldestStar && (persistentPan.x + oldestStar.x) > -1200) {
      // Append 15 more stars further in the negative direction (older dates)
      setStars(prev => {
        const nextList = [...prev];
        const startId = prev.length + 1;
        const currentCount = prev.length;
        for (let i = 0; i < 15; i++) {
          const totalDays = (currentCount + i) * 4 + Math.random() * 3;
          const nextX = oldestStar.x - (i + 1) * 120;
          nextList.push(createStarAt(startId + i, totalDays, nextX));
        }
        return nextList;
      });
    }
  }, [persistentPan, stars]);

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setSearchDate(val);
    if (val) {
      const target = stars.reduce((prev, curr) => {
        return Math.abs(new Date(curr.date).getTime() - new Date(val).getTime()) < Math.abs(new Date(prev.date).getTime() - new Date(val).getTime()) ? curr : prev;
      });
      if (target) {
        panRef.current = { x: -target.x, y: 0 }; setPersistentPan({ x: -target.x, y: 0 }); if (panContainerRef.current) { panContainerRef.current.style.transition = 'transform 0.5s ease'; panContainerRef.current.style.transform = `translateX(${-target.x}px)`; setTimeout(() => { if (panContainerRef.current) panContainerRef.current.style.transition = 'none'; }, 500); } 
        setHighlightId(target.id);
        setActiveStar(target.id);
      }
    }
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    if (e.button !== 0 && e.pointerType === 'mouse') return;
    setIsPanning(true);
    lastPos.current = { x: e.clientX, y: e.clientY };
    e.currentTarget.setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (isPanning) {
      const dx = e.clientX - lastPos.current.x;
      panRef.current.x += dx;
      if (panContainerRef.current) {
        panContainerRef.current.style.transform = `translateX(${panRef.current.x}px)`;
      } // Horizontal infinite panning
      lastPos.current = { x: e.clientX, y: e.clientY };
    }
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (isPanning) {
      setIsPanning(false);
      setPersistentPan({ ...panRef.current });
      e.currentTarget.releasePointerCapture(e.pointerId);
    }
  };

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const preventScroll = (e: TouchEvent) => {
      e.preventDefault();
    };
    el.addEventListener('touchmove', preventScroll, { passive: false });
    return () => el.removeEventListener('touchmove', preventScroll);
  }, []);

  const handleSaveNote = () => {
    if (activeStar !== null) {
      setStars(prev => prev.map(s => s.id === activeStar ? { ...s, memory: editValue, date: editDate } : s));
      setIsEditing(false);
    }
  };

  const handleFileUpload = (starId: number, file: File) => {
    const url = URL.createObjectURL(file);
    setStars(stars.map(s => s.id === starId ? { ...s, mediaUrl: url, mediaFile: file, mediaType: file.type, mediaName: file.name } : s));
  };

  const goToPresent = () => {
    const saved = stars.filter(s => s.memory || s.mediaUrl);
    let target = stars[0];
    if (saved.length > 0) {
      saved.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      target = saved[0];
    }

    panRef.current = { x: -target.x, y: 0 }; 
    setPersistentPan({ x: -target.x, y: 0 }); 
    if (panContainerRef.current) { 
      panContainerRef.current.style.transition = 'transform 0.5s ease'; 
      panContainerRef.current.style.transform = `translateX(${-target.x}px)`; 
      setTimeout(() => { if (panContainerRef.current) panContainerRef.current.style.transition = 'none'; }, 500); 
    }
    
    if (stars.length > 0) {
      setHighlightId(target.id);
      setActiveStar(target.id);
    }
    setIsEditing(false);
  };

  if (!isLoadedStars || !isLoadedActive || !isLoadedPan) return null;

  return (
    <div 
      className="relative w-full h-[80vh] min-h-[500px] overflow-hidden touch-none select-none bg-radial-gradient"
      ref={containerRef}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      style={{ 
        cursor: isPanning ? 'grabbing' : 'grab',
        background: 'radial-gradient(circle at top, #0c122c 0%, #030511 100%)'
      }}
    >
      {/* Premium Shooting Stars (CSS animated) */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-10">
        <div className="absolute top-[10%] left-[80%] w-[2px] h-[120px] bg-gradient-to-t from-white to-transparent rotate-[35deg] opacity-0 animate-[shootingStar_18s_infinite]" style={{ transformOrigin: 'top right' }} />
        <div className="absolute top-[25%] left-[90%] w-[1.5px] h-[90px] bg-gradient-to-t from-purple-200 to-transparent rotate-[40deg] opacity-0 animate-[shootingStar_23s_infinite_4s]" style={{ transformOrigin: 'top right' }} />
        <div className="absolute top-[5%] left-[50%] w-[2px] h-[150px] bg-gradient-to-t from-amber-200 to-transparent rotate-[30deg] opacity-0 animate-[shootingStar_20s_infinite_10s]" style={{ transformOrigin: 'top right' }} />
      </div>

      {/* Decorative Moon */}
      <div className="absolute top-12 right-12 md:right-24 z-10 pointer-events-none w-14 h-14 md:w-20 md:h-20 select-none opacity-80 filter drop-shadow-[0_0_20px_rgba(253,230,138,0.35)]">
        <svg viewBox="0 0 100 100" className="w-full h-full fill-amber-100">
          <path d="M 40 10 C 65 10, 85 30, 85 55 C 85 70, 75 83, 63 90 C 78 80, 85 62, 81 44 C 77 28, 60 16, 43 16 C 42 16, 41 16, 40 16 Z" />
        </svg>
      </div>

      {/* Background Twinkling Star Field (Behind the constellation lines) */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-40">
        {[...Array(35)].map((_, i) => (
          <div
            key={`bg-star-${i}`}
            className="absolute bg-white rounded-full animate-pulse"
            style={{
              top: (i * 7) % 100 + '%',
              left: (i * 13) % 100 + '%',
              width: (i % 3 === 0) ? '2.5px' : '1.5px',
              height: (i % 3 === 0) ? '2.5px' : '1.5px',
              boxShadow: '0 0 8px rgba(255,255,255,0.8)',
              animationDuration: (1.5 + (i % 4) * 0.8) + 's'
            }}
          />
        ))}
      </div>

      {/* Header controls */}
      <div className="absolute top-4 w-full text-center pointer-events-none z-50 flex flex-col items-center gap-3 px-4">
        <div className="bg-slate-950/55 backdrop-blur-md rounded-xl sm:rounded-full py-2 px-3 sm:px-5 pointer-events-auto border border-purple-500/40 shadow-xl inline-flex flex-col sm:flex-row items-center gap-2">
          <div className="flex flex-col sm:flex-row items-center justify-center gap-2 sm:gap-3">
            <div className="flex items-center justify-center gap-2 px-3 py-1.5 sm:py-1 bg-black/40 rounded-full border border-purple-500/20">
              <Calendar size={13} className="text-purple-400 drop-shadow-[0_0_8px_rgba(138,43,226,0.8)]" />
              <input 
                type="date" 
                value={searchDate}
                onChange={handleSearch}
                className="bg-transparent outline-none text-white text-[10px] sm:text-xs font-semibold w-[90px] sm:w-auto"
                style={{ colorScheme: 'dark' }}
              />
            </div>
            
            {/* Go to Present Button */}
            <button 
              onClick={goToPresent}
              className="bg-purple-600/60 hover:bg-purple-500/80 text-white border-2 border-purple-400 rounded-full px-3 sm:px-4 py-1.5 text-[10px] sm:text-xs font-bold transition-all active:scale-95 flex items-center justify-center w-full sm:w-auto gap-1 shadow-[0_0_15px_rgba(138,43,226,0.6)] hover:shadow-[0_0_25px_rgba(138,43,226,1)] hover:scale-105 drop-shadow-[0_0_8px_rgba(138,43,226,1)] uppercase tracking-wide"
            >
              <RotateCcw size={10} className="sm:w-3 sm:h-3" />
              <span>Go to Present</span>
            </button>
          </div>
        </div>
      </div>

      {/* Constellation Canvas wrapper */}
      <div ref={panContainerRef} 
        className="absolute inset-0"
        
        
      >
        <style>{`
          @keyframes starPulse {
            0%, 100% { transform: scale(1); opacity: 0.7; }
            50% { transform: scale(1.4); opacity: 1; }
          }
        `}</style>
        <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ minWidth: '8000px', left: 'calc(50% - 4000px)' }}>
          {stars.map((star, i) => {
            if (i === stars.length - 1) return null;
            const nextStar = stars[i + 1];
            return (
              <line 
                key={`line-${i}`}
                x1={`calc(50% + ${star.x}px)`} 
                y1={`${50 + star.y}%`} 
                x2={`calc(50% + ${nextStar.x}px)`} 
                y2={`${50 + nextStar.y}%`} 
                stroke="rgba(199, 210, 254, 0.28)" 
                strokeWidth="1.2"
                strokeDasharray="4 4"
              />
            )
          })}
        </svg>

        {stars.map((star) => (
          <div
            key={star.id}
            className={`absolute cursor-pointer transition-all duration-300 will-change-transform ${highlightId === star.id ? 'z-50' : 'z-20'}`}
            style={{ 
              left: `calc(50% + ${star.x}px)`, 
              top: `calc(50% + ${star.y}%)`,
              animation: `starPulse ${2 + Math.random() * 2}s ease-in-out ${Math.random() * 2}s infinite`
            }}
            onClick={(e) => { 
              e.stopPropagation(); 
              setActiveStar(star.id); 
              setIsEditing(false);
            }}
          >
            <div 
              className={`rounded-full transition-all ${highlightId === star.id ? 'scale-150' : 'hover:scale-150'}`}
              style={{ width: star.size * 2.2, height: star.size * 2.2, transform: 'translate(-50%, -50%)', backgroundColor: star.color || '#fff', boxShadow: `0 0 ${highlightId === star.id ? '22px 6px' : '12px 2px'} ${star.color || 'rgba(255,255,255,0.5)'}` }}
            />
            <div className={`absolute top-4 left-1/2 -translate-x-1/2 whitespace-nowrap text-purple-200 drop-shadow-[0_0_5px_rgba(138,43,226,0.8)] text-[10px] font-mono transition-opacity pointer-events-none ${highlightId === star.id || star.memory || star.mediaUrl ? 'opacity-100' : 'opacity-0'}`}>
              {star.date}
            </div>
          </div>
        ))}
      </div>

      {/* Bottom status display */}
      <div className="absolute bottom-4 w-full flex justify-between items-center px-4 md:px-8 pointer-events-none z-40">
        <div className="text-purple-400 drop-shadow-[0_0_8px_rgba(138,43,226,0.8)] opacity-50 font-serif text-[11px] md:text-xs bg-black/40 px-3 py-1 rounded-full border border-white/5 backdrop-blur-sm">
          Scrolling indefinitely to earlier times
        </div>
        <button 
          className="text-white font-bold font-serif bg-purple-600/30 px-6 py-2 rounded-full shadow-[0_0_20px_rgba(138,43,226,0.7)] border-2 border-purple-400 backdrop-blur-md pointer-events-auto hover:bg-purple-500/50 hover:shadow-[0_0_30px_rgba(138,43,226,1)] hover:scale-105 active:bg-purple-400 active:scale-95 transition-all duration-300 outline-none drop-shadow-[0_0_10px_rgba(138,43,226,1)] uppercase tracking-widest text-xs"
          onClick={() => {
            if (stars.length > 0) {
              panRef.current = { x: -stars[0].x, y: 0 }; setPersistentPan({ x: -stars[0].x, y: 0 }); if (panContainerRef.current) { panContainerRef.current.style.transition = 'transform 0.5s ease'; panContainerRef.current.style.transform = `translateX(${-stars[0].x}px)`; setTimeout(() => { if (panContainerRef.current) panContainerRef.current.style.transition = 'none'; }, 500); }
              setHighlightId(stars[0].id);
              setActiveStar(stars[0].id);
              setIsEditing(false);
            }
          }}
        >
          Present Position ({stars[0]?.date})
        </button>
      </div>

      {/* Star Modal detail window */}
      <AnimatePresence>
        {activeStar && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.1, ease: "easeOut" }}
            className="absolute inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 pointer-events-auto"
            onClick={() => setActiveStar(null)}
          >
            <motion.div
              initial={{ scale: 0.95, y: 10 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 10 }}
              transition={{ duration: 0.1, ease: "easeOut" }}
              className="bg-slate-900/95 border border-purple-500/50 shadow-[0_0_30px_rgba(138,43,226,0.3)] w-full max-w-sm max-h-[95%] overflow-y-auto custom-scrollbar rounded-xl shadow-[0_20px_50px_rgba(0,0,0,0.7)] p-5 flex flex-col relative"
              onClick={e => e.stopPropagation()}
            >
              <div className="w-full aspect-square md:aspect-[4/5] bg-slate-950 border border-slate-800 mb-4 flex flex-col items-center justify-center text-slate-500 overflow-hidden rounded-lg shadow-inner shrink-0">
                <MediaUpload 
                  mediaUrl={stars.find(s => s.id === activeStar)?.mediaUrl || null}
                  mediaType={stars.find(s => s.id === activeStar)?.mediaType || null}
                  mediaName={stars.find(s => s.id === activeStar)?.mediaName || null}
                  onUpload={(file) => handleFileUpload(activeStar, file)}
                  className="w-full h-full bg-slate-950 border-none"
                />
              </div>
              
              {isEditing ? (
                <div className="flex flex-col gap-2 mt-1">
                  <div className="flex items-center gap-2 bg-black/20 p-1.5 rounded-lg border border-white/5">
                    <input 
                      autoFocus
                      type="text"
                      value={editValue}
                      placeholder="Write a sweet memory..."
                      onChange={e => setEditValue(e.target.value)}
                      onKeyDown={e => e.key === 'Enter' && handleSaveNote()}
                      className="flex-1 text-center font-serif text-sm text-white italic tracking-wide px-2 bg-transparent outline-none"
                    />
                    <button onClick={handleSaveNote} className="text-emerald-400 p-1.5 hover:bg-emerald-950/50 active:scale-90 transition-all rounded shrink-0">
                      <Check size={16} />
                    </button>
                  </div>
                  <div className="flex justify-center">
                    <input 
                      type="date"
                      value={editDate}
                      onChange={e => setEditDate(e.target.value)}
                      className="bg-transparent text-purple-400/80 text-xs font-mono border-b border-purple-400/30 outline-none text-center"
                    />
                  </div>
                </div>
              ) : (
                <div 
                  className="text-center font-serif text-base text-white italic cursor-pointer group hover:bg-white/5 rounded py-2 px-3 flex items-center justify-center gap-2 transition-colors min-h-[36px] bg-white/5 border border-white/5"
                  onClick={() => {
                    // setEditValue is now handled by useEffect
                    setIsEditing(true);
                  }}
                  title="Click to edit memory"
                >
                  <span className="truncate max-w-[280px]">
                    {stars.find(s => s.id === activeStar)?.memory || <span className="text-purple-400/40 not-italic text-sm">Empty memory. Click to write note...</span>}
                  </span>
                  <Edit2 size={12} className="opacity-0 group-hover:opacity-60 text-purple-400 drop-shadow-[0_0_8px_rgba(138,43,226,0.8)]" />
                </div>
              )}
              <div className="text-center text-[10px] text-purple-400/50 mt-3 not-italic font-mono pointer-events-none border-t border-white/5 pt-2">
                Memory Timestamp: {stars.find(s => s.id === activeStar)?.date}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
