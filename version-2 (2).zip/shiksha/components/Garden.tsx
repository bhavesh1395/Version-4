import React, { useState, useMemo, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar, Check, Edit2, RotateCcw } from 'lucide-react';
import { usePersistentState } from '../lib/usePersistentState';
import { MediaUpload } from './MediaUpload';

const flowerTypes = [
  'Rose', 'Tulip', 'Lily', 'Sunflower', 'Daisy', 
  'Orchid', 'Lavender', 'Jasmine', 'Hibiscus', 'Cherry Blossom', 
  'Lotus', 'Marigold', 'Bluebell', 'Carnation', 'Peony'
];

// Draw beautiful premium vector SVGs for all 15 flower types
function FlowerSVG({ type, size = 80 }: { type: string; size?: number }) {
  const uniqId = useMemo(() => Math.random().toString(36).substr(2, 9), [type]);

  switch (type) {
    case 'Rose':
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none" >
          <defs>
            <radialGradient id={`rose-${uniqId}`} cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#f43f5e" />
              <stop offset="60%" stopColor="#be123c" />
              <stop offset="100%" stopColor="#4c0519" />
            </radialGradient>
          </defs>
          {/* Inner petals */}
          <circle cx="50" cy="50" r="14" fill={`url(#rose-${uniqId})`} />
          <path d="M 50 30 C 58 30, 64 36, 64 45 C 64 56, 50 70, 50 70 C 50 70, 36 56, 36 45 C 36 36, 42 30, 50 30 Z" fill={`url(#rose-${uniqId})`} opacity="0.95" />
          <path d="M 50 36 C 42 36, 38 42, 38 48 C 38 56, 50 66, 50 66 C 50 66, 62 56, 62 48 C 62 42, 58 36, 50 36 Z" fill={`url(#rose-${uniqId})`} opacity="0.9" />
          {/* Outer overlapping curved petal layers */}
          <path d="M 50 20 C 65 20, 80 32, 76 52 C 72 72, 50 86, 50 86 C 50 86, 28 72, 24 52 C 20 32, 35 20, 50 20 Z" fill={`url(#rose-${uniqId})`} opacity="0.75" />
          <circle cx="50" cy="46" r="6" fill="#fda4af" opacity="0.6" />
        </svg>
      );
    case 'Tulip':
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none" >
          <defs>
            <linearGradient id={`tulip-${uniqId}`} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fda4af" />
              <stop offset="50%" stopColor="#f43f5e" />
              <stop offset="100%" stopColor="#9f1239" />
            </linearGradient>
          </defs>
          {/* Three overlapping petals forming a tulip cup */}
          <path d="M 30 75 C 20 40, 34 25, 42 35 C 50 25, 60 40, 50 75 Z" fill={`url(#tulip-${uniqId})`} />
          <path d="M 70 75 C 80 40, 66 25, 58 35 C 50 25, 40 40, 50 75 Z" fill={`url(#tulip-${uniqId})`} />
          <path d="M 50 75 C 32 45, 42 22, 50 32 C 58 22, 68 45, 50 75 Z" fill={`url(#tulip-${uniqId})`} opacity="0.95" />
        </svg>
      );
    case 'Lily':
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none" >
          <defs>
            <linearGradient id={`lily-${uniqId}`} x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="70%" stopColor="#fef08a" />
              <stop offset="100%" stopColor="#ca8a04" />
            </linearGradient>
          </defs>
          {/* Star lily radiating petals */}
          <path d="M 50 50 L 50 15 C 53 30, 47 30, 50 50 Z" fill={`url(#lily-${uniqId})`} />
          <path d="M 50 50 L 50 85 C 53 70, 47 70, 50 50 Z" fill={`url(#lily-${uniqId})`} />
          <path d="M 50 50 L 15 50 C 30 53, 30 47, 50 50 Z" fill={`url(#lily-${uniqId})`} />
          <path d="M 50 50 L 85 50 C 70 53, 70 47, 50 50 Z" fill={`url(#lily-${uniqId})`} />
          {/* Diagonal star petals */}
          <path d="M 50 50 L 25 25 C 38 33, 33 38, 50 50 Z" fill={`url(#lily-${uniqId})`} opacity="0.9" />
          <path d="M 50 50 L 75 75 C 62 67, 67 62, 50 50 Z" fill={`url(#lily-${uniqId})`} opacity="0.9" />
          <path d="M 50 50 L 75 25 C 67 38, 62 33, 50 50 Z" fill={`url(#lily-${uniqId})`} opacity="0.9" />
          <path d="M 50 50 L 25 75 C 33 62, 38 67, 50 50 Z" fill={`url(#lily-${uniqId})`} opacity="0.9" />
          {/* Center filaments */}
          <circle cx="50" cy="50" r="5" fill="#ca8a04" />
        </svg>
      );
    case 'Sunflower':
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none" >
          <defs>
            <radialGradient id={`sunCore-${uniqId}`} cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#451a03" />
              <stop offset="80%" stopColor="#78350f" />
              <stop offset="100%" stopColor="#1e1b4b" />
            </radialGradient>
            <linearGradient id={`sunPetal-${uniqId}`} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fef08a" />
              <stop offset="50%" stopColor="#eab308" />
              <stop offset="100%" stopColor="#ca8a04" />
            </linearGradient>
          </defs>
          {/* Radiating narrow gold petals */}
          {[...Array(16)].map((_, i) => (
            <path 
              key={i}
              d="M 50 50 C 42 20, 58 20, 50 50 Z" 
              fill={`url(#sunPetal-${uniqId})`} 
              transform={`rotate(${i * 22.5} 50 50)`}
            />
          ))}
          {/* Textured center seed disc */}
          <circle cx="50" cy="50" r="22" fill={`url(#sunCore-${uniqId})`} stroke="#b45309" strokeWidth="1" />
          <circle cx="50" cy="50" r="14" fill="none" stroke="#eab308" strokeWidth="1.5" strokeDasharray="3 3" className="opacity-45" />
        </svg>
      );
    case 'Daisy':
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none" >
          <defs>
            <linearGradient id={`daisyPetal-${uniqId}`} x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="100%" stopColor="#f1f5f9" />
            </linearGradient>
          </defs>
          {/* Clean, bright white petals */}
          {[...Array(12)].map((_, i) => (
            <path 
              key={i}
              d="M 50 50 C 45 15, 55 15, 50 50 Z" 
              fill={`url(#daisyPetal-${uniqId})`} 
              transform={`rotate(${i * 30} 50 50)`}
            />
          ))}
          {/* Sun yellow center */}
          <circle cx="50" cy="50" r="15" fill="#facc15" stroke="#ca8a04" strokeWidth="1" />
        </svg>
      );
    case 'Orchid':
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none" >
          <defs>
            <linearGradient id={`orchid-${uniqId}`} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#f472b6" />
              <stop offset="50%" stopColor="#c084fc" />
              <stop offset="100%" stopColor="#6b21a8" />
            </linearGradient>
          </defs>
          {/* Broad, elegant orchid wings */}
          <path d="M 50 50 C 20 20, 10 50, 50 50 Z" fill={`url(#orchid-${uniqId})`} />
          <path d="M 50 50 C 80 20, 90 50, 50 50 Z" fill={`url(#orchid-${uniqId})`} />
          <path d="M 50 50 C 30 80, 70 80, 50 50 Z" fill={`url(#orchid-${uniqId})`} opacity="0.9" />
          <path d="M 50 50 C 50 15, 50 15, 50 50 Z" fill={`url(#orchid-${uniqId})`} />
          {/* Complex inner labellum */}
          <circle cx="50" cy="53" r="8" fill="#db2777" />
          <circle cx="50" cy="50" r="4" fill="#facc15" />
        </svg>
      );
    case 'Lavender':
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none" >
          <defs>
            <linearGradient id={`lav-${uniqId}`} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#ddd6fe" />
              <stop offset="60%" stopColor="#8b5cf6" />
              <stop offset="100%" stopColor="#4c1d95" />
            </linearGradient>
          </defs>
          {/* Tall spike of mini stacked blossoms */}
          <line x1="50" y1="90" x2="50" y2="15" stroke="#059669" strokeWidth="2.5" />
          {[...Array(9)].map((_, idx) => {
            const yOffset = 20 + idx * 7;
            return (
              <g key={idx} transform={`translate(0, ${yOffset})`}>
                <circle cx="44" cy="0" r="5" fill={`url(#lav-${uniqId})`} />
                <circle cx="56" cy="0" r="5" fill={`url(#lav-${uniqId})`} />
                <circle cx="50" cy="-3" r="4.5" fill={`url(#lav-${uniqId})`} />
                <circle cx="41" cy="4" r="4" fill={`url(#lav-${uniqId})`} opacity="0.8" />
                <circle cx="59" cy="4" r="4" fill={`url(#lav-${uniqId})`} opacity="0.8" />
              </g>
            );
          })}
        </svg>
      );
    case 'Jasmine':
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none" >
          {/* Delicate 5 star-like white petals */}
          {[...Array(5)].map((_, i) => (
            <path 
              key={i}
              d="M 50 50 C 43 20, 57 20, 50 50 Z" 
              fill="#ffffff" 
              transform={`rotate(${i * 72} 50 50)`}
              stroke="#f1f5f9"
              strokeWidth="0.5"
            />
          ))}
          {/* Light green core */}
          <circle cx="50" cy="50" r="6" fill="#86efac" />
          <circle cx="50" cy="50" r="3" fill="#fef08a" />
        </svg>
      );
    case 'Hibiscus':
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none" >
          <defs>
            <linearGradient id={`hib-${uniqId}`} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#f43f5e" />
              <stop offset="70%" stopColor="#dc2626" />
              <stop offset="100%" stopColor="#7f1d1d" />
            </linearGradient>
          </defs>
          {/* Bold tropical overlapping petals */}
          {[...Array(5)].map((_, i) => (
            <path 
              key={i}
              d="M 50 50 C 20 25, 45 10, 50 50 Z" 
              fill={`url(#hib-${uniqId})`} 
              transform={`rotate(${i * 72} 50 50)`}
            />
          ))}
          {/* Long prominent protruding stamen */}
          <line x1="50" y1="50" x2="72" y2="28" stroke="#fef08a" strokeWidth="3.5" strokeLinecap="round" />
          <circle cx="72" cy="28" r="4.5" fill="#eab308" />
          <circle cx="68" cy="32" r="2.5" fill="#eab308" />
          <circle cx="76" cy="24" r="2.5" fill="#eab308" />
          <circle cx="50" cy="50" r="10" fill="#991b1b" opacity="0.6" />
        </svg>
      );
    case 'Cherry Blossom':
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none" >
          <defs>
            <linearGradient id={`cb-${uniqId}`} x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#ffe4e6" />
              <stop offset="60%" stopColor="#fbcfe8" />
              <stop offset="100%" stopColor="#f472b6" />
            </linearGradient>
          </defs>
          {/* 5 notched petals */}
          {[...Array(5)].map((_, i) => (
            <path 
              key={i}
              d="M 50 50 C 35 15, 38 12, 50 18 C 62 12, 65 15, 50 50 Z" 
              fill={`url(#cb-${uniqId})`} 
              transform={`rotate(${i * 72} 50 50)`}
            />
          ))}
          <circle cx="50" cy="50" r="7" fill="#db2777" opacity="0.4" />
          <circle cx="50" cy="50" r="3" fill="#fdf2f8" />
        </svg>
      );
    case 'Lotus':
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none" >
          <defs>
            <linearGradient id={`lotus-${uniqId}`} x1="0%" y1="100%" x2="0%" y2="0%">
              <stop offset="0%" stopColor="#fbcfe8" />
              <stop offset="70%" stopColor="#f472b6" />
              <stop offset="100%" stopColor="#ffffff" />
            </linearGradient>
          </defs>
          {/* Layered open water-lily lotus shape */}
          <path d="M 50 80 C 15 80, 20 40, 50 20 C 80 40, 85 80, 50 80 Z" fill={`url(#lotus-${uniqId})`} />
          <path d="M 50 80 C 25 80, 30 45, 50 30 C 70 45, 75 80, 50 80 Z" fill={`url(#lotus-${uniqId})`} opacity="0.95" />
          <path d="M 50 80 C 35 80, 38 52, 50 40 C 62 52, 65 80, 50 80 Z" fill={`url(#lotus-${uniqId})`} opacity="0.9" />
          <circle cx="50" cy="72" r="5" fill="#facc15" />
        </svg>
      );
    case 'Marigold':
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none" >
          <defs>
            <radialGradient id={`mari-${uniqId}`} cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#facc15" />
              <stop offset="70%" stopColor="#f97316" />
              <stop offset="100%" stopColor="#7c2d12" />
            </radialGradient>
          </defs>
          {/* Dense double ruffled petals */}
          {[...Array(24)].map((_, i) => (
            <circle 
              key={i}
              cx={50 + Math.cos(i * 15 * Math.PI / 180) * (14 + (i % 3) * 4)}
              cy={50 + Math.sin(i * 15 * Math.PI / 180) * (14 + (i % 3) * 4)}
              r={11 - (i % 3) * 2}
              fill={`url(#mari-${uniqId})`}
              opacity="0.9"
            />
          ))}
          <circle cx="50" cy="50" r="12" fill="#ea580c" />
          <circle cx="50" cy="50" r="6" fill="#facc15" />
        </svg>
      );
    case 'Bluebell':
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none" >
          <defs>
            <linearGradient id={`blueb-${uniqId}`} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#bfdbfe" />
              <stop offset="60%" stopColor="#3b82f6" />
              <stop offset="100%" stopColor="#1d4ed8" />
            </linearGradient>
          </defs>
          {/* Drooping stem and bells */}
          <path d="M 30 80 Q 45 25 70 30" fill="none" stroke="#059669" strokeWidth="2.5" />
          <g transform="translate(42, 45) rotate(40)">
            <path d="M -12 -5 C -15 15, 15 15, 12 -5 C 8 8, -8 8, -12 -5 Z" fill={`url(#blueb-${uniqId})`} />
          </g>
          <g transform="translate(56, 35) rotate(30)">
            <path d="M -10 -5 C -13 13, 13 13, 10 -5 C 7 7, -7 7, -10 -5 Z" fill={`url(#blueb-${uniqId})`} />
          </g>
        </svg>
      );
    case 'Carnation':
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none" >
          <defs>
            <linearGradient id={`carna-${uniqId}`} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fdf2f8" />
              <stop offset="50%" stopColor="#ec4899" />
              <stop offset="100%" stopColor="#be185d" />
            </linearGradient>
          </defs>
          {/* Multiple ruffle fringed petals */}
          {[...Array(8)].map((_, i) => (
            <path 
              key={i}
              d="M 50 50 C 30 20, 70 20, 50 50 Z" 
              fill={`url(#carna-${uniqId})`} 
              transform={`rotate(${i * 45} 50 50)`}
              stroke="#db2777"
              strokeWidth="0.5"
            />
          ))}
          <circle cx="50" cy="50" r="14" fill="#be185d" opacity="0.8" />
          <circle cx="50" cy="50" r="6" fill="#fdf2f8" />
        </svg>
      );
    case 'Peony':
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none" >
          <defs>
            <radialGradient id={`peony-${uniqId}`} cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#fbcfe8" />
              <stop offset="60%" stopColor="#ec4899" />
              <stop offset="100%" stopColor="#9d174d" />
            </radialGradient>
          </defs>
          {/* Dense layered peony sphere */}
          {[...Array(30)].map((_, i) => {
            const rot = i * 12;
            const radius = 8 + (i % 4) * 4;
            return (
              <circle 
                key={i}
                cx={50 + Math.cos(rot * Math.PI / 180) * radius}
                cy={50 + Math.sin(rot * Math.PI / 180) * radius}
                r="12"
                fill={`url(#peony-${uniqId})`}
                opacity="0.85"
              />
            );
          })}
          <circle cx="50" cy="50" r="14" fill="#db2777" />
          <circle cx="50" cy="50" r="7" fill="#fbcfe8" opacity="0.6" />
        </svg>
      );
    default:
      return <div className="text-4xl">🌸</div>;
  }
}

// Generate single flower helper
const createFlowerAt = (id: number, offsetDays: number, leftCoordinate: number) => {
  const date = new Date(Date.now() - offsetDays * 24 * 60 * 60 * 1000);
  const type = flowerTypes[id % flowerTypes.length];
  return {
    id,
    type,
    left: leftCoordinate,
    height: 25 + Math.random() * 35, // 25 to 60 vh stem height
    delay: Math.random() * 1.5,
    note: "", // strictly empty initial notes as requested
    date: date.toISOString().split('T')[0],
    color: `hsl(${135 + Math.random() * 35}, 75%, 35%)`, // Stem green shading
    mediaUrl: null as string | null,
    mediaFile: null as Blob | null,
    mediaType: null as string | null,
    mediaName: null as string | null
  };
};

const generateInitialFlowers = () => {
  const generated = [];
  for (let i = 0; i < 40; i++) {
    // Spaced left coordinates from newest (center/right) to oldest (far left)
    generated.push(createFlowerAt(i + 1, i * 4 + Math.random() * 2, -i * 140 + 200));
  }
  return generated;
};

const starColors = ['#fde047', '#f472b6', '#a78bfa', '#60a5fa', '#34d399', '#fbbf24', '#ffedd5'];

function GardenStar({ color, delay }: { color: string, delay: number, key?: any }) {
  const randomAnimation = useMemo(() => {
    return {
      x: [
        Math.random() * 600 - 300, 
        Math.random() * 1200 - 600, 
        Math.random() * -1200 + 600, 
        Math.random() * 600 - 300
      ],
      y: [
        Math.random() * 400 - 200, 
        Math.random() * -400 + 200, 
        Math.random() * 400 - 200,
        Math.random() * 400 - 200
      ],
      duration: 12 + Math.random() * 8
    };
  }, []);

  return (
    <div
      className="absolute top-1/2 left-1/2 z-20 pointer-events-none will-change-transform"
      style={{
        '--x1': `${randomAnimation.x[0]}px`,
        '--x2': `${randomAnimation.x[1]}px`,
        '--x3': `${randomAnimation.x[2]}px`,
        '--x4': `${randomAnimation.x[3]}px`,
        '--y1': `${randomAnimation.y[0]}px`,
        '--y2': `${randomAnimation.y[1]}px`,
        '--y3': `${randomAnimation.y[2]}px`,
        '--y4': `${randomAnimation.y[3]}px`,
        animation: `gardenStarFloat ${randomAnimation.duration}s ease-in-out ${delay}s infinite alternate`
      } as React.CSSProperties}
    >
      <div
        className="relative w-4 h-4 md:w-5 md:h-5 opacity-90 will-change-transform"
        style={{
          animation: `gardenStarSpin ${3 + Math.random() * 3}s linear infinite, gardenStarPulse ${1.5 + Math.random()}s ease-in-out infinite alternate`,
          boxShadow: `0 0 6px ${color}`
        }}
      >
        <svg viewBox="0 0 24 24" fill={color} className="w-full h-full">
          <path d="M12 0L14.6 9.4L24 12L14.6 14.6L12 24L9.4 14.6L0 12L9.4 9.4Z" />
        </svg>
      </div>
    </div>
  );
}

// Persistent module-level cache
export function Garden() {
  const [flowers, setFlowers, isLoadedFlowers] = usePersistentState('garden_flowers', generateInitialFlowers);
  const [activeFlower, setActiveFlower, isLoadedActive] = usePersistentState<number | null>('garden_active', null);
  const [persistentPan, setPersistentPan, isLoadedPan] = usePersistentState('garden_pan', { x: 0, y: 0 });
  const panRef = useRef({ x: 0, y: 0 });
  const panContainerRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (isLoadedPan) {
      panRef.current = { ...persistentPan };
      if (panContainerRef.current) {
        panContainerRef.current.style.transform = `translateX(${persistentPan.x}px)`;
      }
    }
  }, [isLoadedPan]);
  const [isPanning, setIsPanning] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const lastPos = useRef({ x: 0, y: 0 });

  const [searchDate, setSearchDate] = useState('');
  const [highlightId, setHighlightId] = useState<number | null>(null);

  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState("");

  useEffect(() => {
    // INFINITE SCROLL TRIGGER
    // If user approaches oldest flower boundary (far left), dynamically generate more!
    const oldestFlower = flowers[flowers.length - 1];
    if (oldestFlower && (persistentPan.x + oldestFlower.left) > -1200) {
      setFlowers(prev => {
        const nextList = [...prev];
        const startId = prev.length + 1;
        const currentCount = prev.length;
        for (let i = 0; i < 15; i++) {
          const totalDays = (currentCount + i) * 4 + Math.random() * 2;
          const nextLeft = oldestFlower.left - (i + 1) * 140;
          nextList.push(createFlowerAt(startId + i, totalDays, nextLeft));
        }
        return nextList;
      });
    }
  }, [persistentPan, flowers]);

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setSearchDate(val);
    if (val) {
      const target = flowers.reduce((prev, curr) => {
        return Math.abs(new Date(curr.date).getTime() - new Date(val).getTime()) < Math.abs(new Date(prev.date).getTime() - new Date(val).getTime()) ? curr : prev;
      });
      if (target) {
        panRef.current = { x: -target.left, y: 0 }; setPersistentPan({ x: -target.left, y: 0 }); if (panContainerRef.current) { panContainerRef.current.style.transition = 'transform 0.5s ease'; panContainerRef.current.style.transform = `translateX(${-target.left}px)`; setTimeout(() => { if (panContainerRef.current) panContainerRef.current.style.transition = 'none'; }, 500); } 
        setHighlightId(target.id);
        setActiveFlower(target.id);
      }
    }
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    if (e.button !== 0 && e.pointerType === 'mouse') return;
    setIsPanning(true);
    lastPos.current = { x: e.clientX, y: e.clientY };
    e.currentTarget.setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (isPanning) {
      const dx = e.clientX - lastPos.current.x;
      panRef.current.x += dx;
      if (panContainerRef.current) {
        panContainerRef.current.style.transform = `translateX(${panRef.current.x}px)`;
      } // Horizontal infinite panning
      lastPos.current = { x: e.clientX, y: e.clientY };
    }
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (isPanning) {
      setIsPanning(false);
      setPersistentPan({ ...panRef.current });
      e.currentTarget.releasePointerCapture(e.pointerId);
    }
  };

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const preventScroll = (e: TouchEvent) => {
      e.preventDefault();
    };
    el.addEventListener('touchmove', preventScroll, { passive: false });
    return () => el.removeEventListener('touchmove', preventScroll);
  }, []);

  const handleSaveNote = () => {
    if (activeFlower !== null) {
      setFlowers(prev => prev.map(f => f.id === activeFlower ? { ...f, note: editValue } : f));
      setIsEditing(false);
    }
  };

  const handleFileUpload = (flowerId: number, file: File) => {
    const url = URL.createObjectURL(file);
    setFlowers(flowers.map(f => f.id === flowerId ? { ...f, mediaUrl: url, mediaFile: file, mediaType: file.type, mediaName: file.name } : f));
  };

  const goToPresent = () => {
    const saved = flowers.filter(f => f.note || f.mediaUrl);
    let target = flowers[0];
    if (saved.length > 0) {
      saved.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      target = saved[0];
    }
    
    panRef.current = { x: -target.x, y: 0 }; 
    setPersistentPan({ x: -target.x, y: 0 }); 
    if (panContainerRef.current) { 
      panContainerRef.current.style.transition = 'transform 0.5s ease'; 
      panContainerRef.current.style.transform = `translateX(${-target.x}px)`; 
      setTimeout(() => { if (panContainerRef.current) panContainerRef.current.style.transition = 'none'; }, 500); 
    }
    
    if (flowers.length > 0) {
      setHighlightId(target.id);
      setActiveFlower(target.id);
    }
    setIsEditing(false);
  };

  if (!isLoadedFlowers || !isLoadedActive || !isLoadedPan) return null;

  return (
    <div 
      className="relative w-full h-[80vh] min-h-[500px] overflow-hidden flex flex-col items-center justify-end border-t border-white/5 touch-none"
      ref={containerRef}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      style={{ 
        cursor: isPanning ? 'grabbing' : 'grab',
        background: 'linear-gradient(to top, rgba(6, 78, 59, 0.25) 0%, transparent 100%)'
      }}
    >
      <div className="absolute top-10 text-center pointer-events-none px-4 z-50 flex flex-col items-center gap-3 w-full">
        <div className="bg-emerald-950/50 backdrop-blur-md rounded-xl sm:rounded-full py-2 px-3 sm:px-5 pointer-events-auto border border-emerald-500/20 shadow-xl flex flex-col sm:flex-row items-center justify-center gap-2 sm:gap-3">
          <div className="flex items-center justify-center gap-2 bg-emerald-900/30 px-3 py-1.5 sm:py-1 rounded-full border border-emerald-500/20">
            <Calendar size={13} className="text-emerald-300" />
            <input 
              type="date" 
              value={searchDate}
              onChange={handleSearch}
              className="bg-transparent outline-none text-emerald-100 text-[10px] sm:text-xs font-semibold w-[90px] sm:w-auto"
              style={{ colorScheme: 'dark' }}
            />
          </div>
          
          <button 
            onClick={goToPresent}
            className="bg-emerald-600/35 hover:bg-emerald-500/50 text-emerald-100 border border-emerald-400/30 rounded-full px-3 py-1.5 sm:py-1 text-[10px] sm:text-xs font-medium transition-all active:scale-95 flex items-center justify-center gap-1 hover:shadow-[0_0_12px_rgba(16,185,129,0.35)] w-full sm:w-auto"
          >
            <RotateCcw size={10} className="sm:w-3 sm:h-3" />
            <span>Go to Present</span>
          </button>
        </div>
      </div>

      <div ref={panContainerRef} 
        className="absolute inset-0"
        
        
      >
        <style>{`
          @keyframes gardenStarFloat {
            0% { transform: translate(var(--x1), var(--y1)); }
            33% { transform: translate(var(--x2), var(--y2)); }
            66% { transform: translate(var(--x3), var(--y3)); }
            100% { transform: translate(var(--x4), var(--y4)); }
          }
          @keyframes gardenStarSpin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
          @keyframes gardenStarPulse {
            0%, 100% { transform: scale(0.8); }
            50% { transform: scale(1.2); }
          }
          @keyframes flowerSway {
            0%, 100% { transform: rotate(-2.5deg); }
            50% { transform: rotate(2.5deg); }
          }
          @keyframes flowerGrow {
            0% { transform: scaleY(0); }
            100% { transform: scaleY(1); }
          }
          @keyframes leafGrow {
            0% { transform: scale(0); }
            100% { transform: scale(1); }
          }
        `}</style>
        {[...Array(15)].map((_, i) => (
          <GardenStar key={i} color={starColors[i % starColors.length]} delay={i * 1.5} />
        ))}
        <div className="relative w-full h-full">
          {flowers.map((flower) => (
            <div 
              key={flower.id} 
              className="absolute bottom-0 flex flex-col items-center transform -translate-x-1/2" 
              style={{ left: `calc(50% + ${flower.left}px)` }}
            >
              
              <div
                className={`cursor-pointer z-30 relative transition-all duration-300 will-change-transform ${highlightId === flower.id ? 'scale-120 z-50' : 'hover:scale-110'}`}
                style={{
                  animation: `flowerSway ${4 + (flower.id % 3)}s ease-in-out ${flower.delay}s infinite`
                }}
                onClick={(e) => { 
                  e.stopPropagation(); 
                  setActiveFlower(flower.id); 
                  setIsEditing(false);
                }}
              >
                <div className={`transition-all duration-300 origin-bottom ${highlightId === flower.id ? 'shadow-[0_0_20px_rgba(244,114,182,0.9)] scale-120' : 'shadow-md'}`}>
                  <FlowerSVG type={flower.type} size={80} />
                </div>
                <div className={`absolute -bottom-2 left-1/2 -translate-x-1/2 whitespace-nowrap bg-emerald-950/90 px-2 py-0.5 rounded text-[9px] text-emerald-100 font-mono transition-opacity pointer-events-none border border-emerald-500/20 ${highlightId === flower.id || flower.note || flower.mediaUrl ? 'opacity-100' : 'opacity-0'}`}>
                  {flower.type} · {flower.date}
                </div>
              </div>
              
              {/* Thick stems with delicate leaf branches */}
              <div
                className="w-1.5 md:w-2 rounded-t-full shadow-[0_0_15px_rgba(16,185,129,0.25)] relative pointer-events-none"
                style={{ 
                  height: `${flower.height}vh`, 
                  transformOrigin: 'bottom', 
                  backgroundColor: flower.color, 
                  backgroundImage: 'linear-gradient(to top, rgba(0,0,0,0.3), transparent)',
                  animation: `flowerGrow 2s ease-out ${flower.delay}s both`
                }}
              >
                <div 
                  className="absolute top-1/3 w-3 h-6 rounded-full rounded-tr-none rotate-45 transform origin-bottom-right"
                  style={{ left: '-10px', backgroundColor: flower.color, opacity: 0.75, animation: `leafGrow 0.5s ease-out ${flower.delay + 0.8}s both` }}
                />
                <div 
                  className="absolute top-2/3 w-3 h-6 rounded-full rounded-tl-none -rotate-45 transform origin-bottom-left"
                  style={{ right: '-10px', backgroundColor: flower.color, opacity: 0.75, animation: `leafGrow 0.5s ease-out ${flower.delay + 1.2}s both` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      <AnimatePresence>
        {activeFlower && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.1, ease: "easeOut" }}
            className="absolute inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 pointer-events-auto"
            onClick={() => setActiveFlower(null)}
          >
            <motion.div
              initial={{ scale: 0.95, y: 10 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 10 }}
              transition={{ duration: 0.1, ease: "easeOut" }}
              className="bg-slate-900/95 border border-emerald-500/30 w-full max-w-sm rounded-xl shadow-[0_20px_50px_rgba(0,0,0,0.7)] p-5 flex flex-col relative"
              onClick={e => e.stopPropagation()}
            >
              <div className="w-full aspect-[4/5] bg-slate-950 border border-slate-800 mb-4 flex flex-col items-center justify-center text-emerald-500 overflow-hidden rounded-lg shadow-inner">
                <MediaUpload 
                  mediaUrl={flowers.find(f => f.id === activeFlower)?.mediaUrl || null}
                  mediaType={flowers.find(f => f.id === activeFlower)?.mediaType || null}
                  mediaName={flowers.find(f => f.id === activeFlower)?.mediaName || null}
                  onUpload={(file) => handleFileUpload(activeFlower, file)}
                  className="w-full h-full bg-slate-950 border-none"
                />
              </div>
              
              {isEditing ? (
                <div className="flex items-center gap-2 mt-1 bg-black/20 p-1.5 rounded-lg border border-white/5">
                  <input 
                    autoFocus
                    type="text"
                    value={editValue}
                    placeholder="Write a warm note..."
                    onChange={e => setEditValue(e.target.value)}
                    onBlur={handleSaveNote}
                    onKeyDown={e => e.key === 'Enter' && handleSaveNote()}
                    className="flex-1 text-center font-serif text-sm text-emerald-100 italic tracking-wide px-2 bg-transparent outline-none"
                  />
                  <button onClick={handleSaveNote} className="text-emerald-400 p-1.5 hover:bg-emerald-950/50 active:scale-90 transition-all rounded">
                    <Check size={16} />
                  </button>
                </div>
              ) : (
                <div 
                  className="text-center font-serif text-base text-emerald-100 italic cursor-pointer group hover:bg-white/5 rounded py-2 px-3 flex items-center justify-center gap-2 transition-colors min-h-[36px] bg-white/5 border border-white/5"
                  onClick={() => {
                    setEditValue(flowers.find(f => f.id === activeFlower)?.note || '');
                    setIsEditing(true);
                  }}
                  title="Click to edit note"
                >
                  <span className="truncate max-w-[280px]">
                    {flowers.find(f => f.id === activeFlower)?.note || <span className="text-emerald-400/40 not-italic text-sm">Empty note. Click to write memory...</span>}
                  </span>
                  <Edit2 size={12} className="opacity-0 group-hover:opacity-60 text-emerald-300" />
                </div>
              )}
              <div className="text-center text-[10px] text-emerald-400/50 mt-3 not-italic font-mono pointer-events-none border-t border-white/5 pt-2">
                Type: {flowers.find(f => f.id === activeFlower)?.type} · Placed on: {flowers.find(f => f.id === activeFlower)?.date}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
