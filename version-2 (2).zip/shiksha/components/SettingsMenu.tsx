import React, { useState, useRef, useEffect } from 'react';
import { Settings, X, Key, Music, Upload, Link, Trash2, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { PLAYLIST } from '../songs';
import { saveCustomSong, clearCustomSong, getAllCustomSongs } from '../lib/indexedDbHelper';

interface SettingsMenuProps {
  settings: {
    cursorButterflies: boolean;
    atmosphere: boolean;
    songId: string;
    appTheme: string;
    customColor?: string;
    youtubeUrls?: { id: string, name: string, url: string }[];
    youtubeUrl?: string; // legacy support
    customSongName?: string; // legacy support
  };
  setSettings: (s: any) => void;
}

export function SettingsMenu({ settings, setSettings }: SettingsMenuProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [savedMessage, setSavedMessage] = useState(false);
  const [ytUrl, setYtUrl] = useState('');
  const [ytName, setYtName] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const [customSongs, setCustomSongs] = useState<{id: string, name: string}[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    getAllCustomSongs().then(setCustomSongs);
  }, []);

  const toggleSetting = (key: 'cursorButterflies' | 'atmosphere') => {
    setSettings((prev: any) => ({ ...prev, [key]: !prev[key] }));
  };

  const handleSavePassword = () => {
    if (newPassword.trim() === '') {
      localStorage.removeItem('app_password');
    } else {
      localStorage.setItem('app_password', newPassword);
    }
    setSavedMessage(true);
    setTimeout(() => setSavedMessage(false), 2000);
    setNewPassword('');
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('audio/')) {
      setUploadError('Please select a valid audio file.');
      return;
    }

    setIsUploading(true);
    setUploadError('');

    try {
      const { id, name } = await saveCustomSong(file);
      setCustomSongs(prev => [...prev, { id, name }]);
      setSettings((prev: any) => ({
        ...prev,
        songId: id
      }));
    } catch (err) {
      setUploadError('Failed to save song. Try a smaller file.');
      console.error(err);
    } finally {
      setIsUploading(false);
    }
  };

  const handleSaveYoutube = () => {
    if (!ytUrl.trim() || !ytName.trim()) {
      return;
    }

    const newId = 'youtube_' + Date.now();
    setSettings((prev: any) => {
      const urls = prev.youtubeUrls || [];
      return {
        ...prev,
        songId: newId,
        youtubeUrls: [...urls, { id: newId, name: ytName, url: ytUrl }]
      };
    });
    setYtUrl('');
    setYtName('');
  };

  const handleRemoveCustomSong = async (id: string) => {
    try {
      await clearCustomSong(id);
      setCustomSongs(prev => prev.filter(s => s.id !== id));
      setSettings((prev: any) => {
        const copy = { ...prev };
        if (copy.songId === id) {
          copy.songId = PLAYLIST[0].id;
        }
        return copy;
      });
    } catch (err) {
      console.error(err);
    }
  };

  const handleRemoveYoutube = (id: string) => {
    setSettings((prev: any) => {
      const copy = { ...prev };
      copy.youtubeUrls = (copy.youtubeUrls || []).filter((y: any) => y.id !== id);
      if (copy.songId === id) {
        copy.songId = PLAYLIST[0].id;
      }
      return copy;
    });
  };

  return (
    <>
      <button 
        onClick={() => setIsOpen(true)}
        className="fixed top-6 right-20 z-50 bg-black/30 hover:bg-black/50 backdrop-blur-md p-3.5 rounded-full text-white/90 transition-all duration-150 border border-white/10 shadow-lg group hover:scale-105 active:scale-95 active:bg-rose-500/80"
        id="settings-trigger-btn"
      >
        <Settings size={22} className="text-white/70 group-hover:text-amber-200 transition-colors" />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-black/70 backdrop-blur-md flex items-center justify-center p-4"
            onClick={() => setIsOpen(false)}
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-slate-900/95 border border-indigo-500/20 p-6 md:p-8 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.6)] w-full max-w-md max-h-[85vh] overflow-y-auto scrollbar-thin scrollbar-thumb-white/10"
            >
              <div className="flex items-center justify-between mb-6 border-b border-white/5 pb-4">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-indigo-500/10 rounded-xl border border-indigo-500/20">
                    <Settings className="text-indigo-400 w-5 h-5" />
                  </div>
                  <h2 className="text-2xl font-serif text-slate-100 font-semibold tracking-wide">Settings</h2>
                </div>
                <button onClick={() => setIsOpen(false)} className="text-white/40 hover:text-white transition-colors p-2 rounded-full hover:bg-white/5">
                  <X size={20} />
                </button>
              </div>

              <div className="flex flex-col gap-6">
                
                {/* Switches Section */}
                <div className="flex flex-col gap-4 bg-white/5 p-4 rounded-xl border border-white/5">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-white text-sm font-medium">Cursor Stars Effect</h3>
                      <p className="text-white/40 text-xs mt-0.5">Stars trail gracefully behind your cursor</p>
                    </div>
                    <button 
                      onClick={() => toggleSetting('cursorButterflies')}
                      className={`relative w-11 h-6 rounded-full transition-colors duration-300 shrink-0 ${settings.cursorButterflies ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.4)]' : 'bg-slate-700'}`}
                    >
                      <motion.div 
                        className="absolute top-1 left-1 w-4 h-4 rounded-full bg-white shadow-md"
                        animate={{ x: settings.cursorButterflies ? 20 : 0 }}
                        transition={{ type: "spring", stiffness: 500, damping: 30 }}
                      />
                    </button>
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t border-white/5">
                    <div>
                      <h3 className="text-white text-sm font-medium">Atmosphere Particles</h3>
                      <p className="text-white/40 text-xs mt-0.5">Ambient fireflies and glowing particles</p>
                    </div>
                    <button 
                      onClick={() => toggleSetting('atmosphere')}
                      className={`relative w-11 h-6 rounded-full transition-colors duration-300 shrink-0 ${settings.atmosphere ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.4)]' : 'bg-slate-700'}`}
                    >
                      <motion.div 
                        className="absolute top-1 left-1 w-4 h-4 rounded-full bg-white shadow-md"
                        animate={{ x: settings.atmosphere ? 20 : 0 }}
                        transition={{ type: "spring", stiffness: 500, damping: 30 }}
                      />
                    </button>
                  </div>
                </div>

                {/* Background Music Section */}
                <div className="flex flex-col gap-3 pt-4 border-t border-white/5">
                  <div className="flex items-center gap-2">
                    <Music size={16} className="text-amber-400" />
                    <h3 className="text-white text-sm font-semibold tracking-wide">Background Audio</h3>
                  </div>
                  <p className="text-white/50 text-xs leading-relaxed">Choose a standard instrumental track, import an audio file permanently, or enter a YouTube stream link.</p>
                  
                  <select 
                    value={settings.songId}
                    onChange={(e) => setSettings((prev: any) => ({ ...prev, songId: e.target.value }))}
                    className="w-full bg-slate-950 border border-white/10 rounded-lg px-3.5 py-2.5 text-white outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400/20 text-xs transition-colors"
                  >
                    <option value="">No Background Audio</option>
                    {PLAYLIST.length > 0 && (
                      <optgroup label="Standard Tracks">
                        {PLAYLIST.map(song => (
                          <option key={song.id} value={song.id}>{song.title}</option>
                        ))}
                      </optgroup>
                    )}
                    
                    {customSongs.length > 0 && (
                      <optgroup label="Device Storage">
                        {customSongs.map(song => (
                          <option key={song.id} value={song.id}>{song.name}</option>
                        ))}
                      </optgroup>
                    )}
                    
                    {(settings.youtubeUrls || []).length > 0 && (
                      <optgroup label="YouTube Links">
                        {(settings.youtubeUrls || []).map((song: any) => (
                          <option key={song.id} value={song.id}>{song.name}</option>
                        ))}
                      </optgroup>
                    )}
                  </select>

                  {/* Device Storage Permanent Import */}
                  <div className="bg-slate-950/60 p-3 rounded-lg border border-white/5 flex flex-col gap-2 mt-1">
                    <div className="flex items-center justify-between">
                      <span className="text-white/70 text-xs font-medium">Device Permanent Import</span>
                    </div>
                    
                    <input 
                      type="file" 
                      accept="audio/*" 
                      ref={fileInputRef}
                      onChange={handleFileChange}
                      className="hidden"
                    />

                    <button
                      onClick={() => fileInputRef.current?.click()}
                      disabled={isUploading}
                      className="w-full py-2 px-3 bg-slate-900 hover:bg-slate-850 active:scale-[0.98] transition-all rounded text-xs border border-white/10 hover:border-amber-500/40 text-amber-100/90 font-medium flex items-center justify-center gap-2"
                    >
                      <Upload size={14} />
                      {isUploading ? 'Importing File...' : 'Select File from Storage'}
                    </button>
                    {uploadError && <p className="text-red-400 text-[11px] mt-0.5">{uploadError}</p>}
                    
                    {customSongs.length > 0 && (
                      <div className="flex flex-col gap-1 mt-2">
                        {customSongs.map(song => (
                          <div key={song.id} className="flex items-center justify-between gap-2 text-emerald-400 text-xs bg-emerald-500/10 p-2 rounded border border-emerald-500/20">
                            <div className="flex items-center gap-2 truncate">
                              <Check size={14} className="shrink-0" />
                              <span className="truncate">{song.name}</span>
                            </div>
                            <button 
                              onClick={() => handleRemoveCustomSong(song.id)}
                              className="text-rose-400 hover:text-rose-300 p-1 rounded hover:bg-rose-500/10 transition-colors shrink-0"
                              title="Delete imported song"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* YouTube Link Integration */}
                  <div className="bg-slate-950/60 p-3 rounded-lg border border-white/5 flex flex-col gap-2">
                    <span className="text-white/70 text-xs font-medium">YouTube Background Stream</span>
                    <div className="flex flex-col gap-2">
                      <input 
                        type="text" 
                        placeholder="Song Name..."
                        value={ytName}
                        onChange={(e) => setYtName(e.target.value)}
                        className="w-full bg-slate-900 border border-white/10 focus:border-indigo-400 rounded px-3 py-1.5 text-xs text-white outline-none placeholder:text-white/20"
                      />
                      <div className="flex gap-2">
                        <input 
                          type="text" 
                          placeholder="Paste YouTube watch URL..."
                          value={ytUrl}
                          onChange={(e) => setYtUrl(e.target.value)}
                          className="flex-1 bg-slate-900 border border-white/10 focus:border-indigo-400 rounded px-3 py-1.5 text-xs text-white outline-none placeholder:text-white/20"
                        />
                        <button 
                          onClick={handleSaveYoutube}
                          disabled={!ytName.trim() || !ytUrl.trim()}
                          className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:hover:bg-indigo-600 px-3 py-1.5 rounded text-xs text-white transition-colors flex items-center justify-center"
                          title="Save YouTube URL"
                        >
                          <Link size={14} />
                        </button>
                      </div>
                    </div>
                    
                    {(settings.youtubeUrls || []).length > 0 && (
                      <div className="flex flex-col gap-1 mt-1">
                        {(settings.youtubeUrls || []).map((song: any) => (
                          <div key={song.id} className="flex items-center justify-between text-[11px] text-indigo-400 bg-indigo-500/10 p-2 rounded border border-indigo-500/20">
                            <div className="flex items-center gap-1 truncate">
                              <Check size={10} className="shrink-0" />
                              <span className="truncate">{song.name}</span>
                            </div>
                            <button 
                              onClick={() => handleRemoveYoutube(song.id)}
                              className="text-rose-400 hover:text-rose-300 p-1 rounded hover:bg-rose-500/10 transition-colors shrink-0"
                              title="Delete YouTube URL"
                            >
                              <Trash2 size={12} />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* App Theme Section */}
                <div className="flex flex-col gap-3 pt-4 border-t border-white/5">
                  <div className="flex items-center gap-2">
                    <Settings size={16} className="text-indigo-400" />
                    <h3 className="text-white text-sm font-semibold tracking-wide font-sans">Background Landscape</h3>
                  </div>
                  <p className="text-white/50 text-xs">Transform the backdrop with luxurious colors and atmospheres.</p>
                  <select 
                    value={settings.appTheme || 'default'}
                    onChange={(e) => setSettings((prev: any) => ({ ...prev, appTheme: e.target.value }))}
                    className="w-full bg-slate-950 border border-white/10 rounded-lg px-3.5 py-2.5 outline-none focus:border-indigo-400 focus:ring-1 focus:ring-indigo-400/20 text-xs transition-colors" style={settings.appTheme === 'shiksha-fall' ? { fontWeight: 900, color: '#ff1493', textTransform: 'uppercase' } : { color: 'white' }}
                  >
                    <option value="default">Default Dark Space</option>
                    
                    <option value="custom">Custom Solid / Neon Color</option>
                    <option value="romantic">Romantic Rosewood</option>
                    <option value="nature">Nature Woodland</option>
                    <option value="galaxy">Cosmic Galaxy</option>
                    <option value="realistic">Sunset Beach</option>
                    
                    <option value="sakura">Sakura Blossom</option>
                    <option value="lavender">Lavender Garden</option>
                    <option value="sunset">Sunset Sky</option>
                    <option value="aurora">Northern Lights</option>
                    <option value="rainy">Rainy Evening</option>
                    <option value="autumn">Autumn Forest</option>
                    <option value="winter">Snow Winter</option>
                    <option value="ocean">Ocean Blue</option>
                    <option value="mountain">Mountain View</option>
                    <option value="clouds">Dream Clouds</option>
                    <option value="vintage">Vintage Paper</option>
                    <option value="watercolor">Watercolor Abstract</option>
                    <option value="pastel">Pastel Theme</option>
                    <option value="golden">Golden Evening</option>
                    <option value="cherry">Cherry Blossom Valley</option>
                    <option value="butterfly">Butterfly Garden</option>
                    <option value="fireflies">Fireflies Enchanted Night</option>
                    <option value="minimal">Minimal White</option>
                    <option value="pink">Soft Pink Quartz</option>
                    <option value="shiksha-fall" style={{ fontWeight: '900', color: '#ff1493' }} className="text-pink-500 font-black">💖 𝗦𝗛𝗜𝗞𝗦𝗛𝗔 💖</option>
                  </select>
                  
                  {settings.appTheme === 'custom' && (
                    <div className="flex flex-col gap-3 mt-2 bg-slate-950/60 p-3 rounded-lg border border-white/5">
                      <span className="text-white/70 text-xs font-medium border-b border-white/5 pb-2">Color Palette</span>
                      
                      <div className="grid grid-cols-6 gap-2">
                        {['#000000', '#111827', '#1e1b4b', '#4c1d95', '#831843', '#7f1d1d',
                          '#ff007f', '#00e5ff', '#39ff14', '#8a2be2', '#ffff00', '#ff5e00',
                          '#ffb6c1', '#add8e6', '#98fb98', '#e6e6fa', '#fffacd', '#ffdab9'].map(color => (
                          <button
                            key={color}
                            onClick={() => setSettings((prev: any) => ({ ...prev, customColor: color }))}
                            className={`w-full aspect-square rounded-md border-2 transition-transform hover:scale-110 ${settings.customColor === color ? 'border-white' : 'border-white/10'}`}
                            style={{ backgroundColor: color, boxShadow: color.match(/ff|00e|39f|8a2/i) && color !== '#ffffff' && color !== '#000000' && !color.match(/add8e6|98fb98|e6e6fa|fffacd|ffdab9|ffb6c1/) ? `0 0 10px ${color}80` : 'none' }}
                            title={color}
                          />
                        ))}
                      </div>

                      <div className="flex items-center justify-between mt-1 pt-3 border-t border-white/5">
                        <span className="text-white/50 text-xs">Custom picker:</span>
                        <input
                          type="color"
                          value={settings.customColor || '#1f2937'}
                          onChange={(e) => setSettings((prev: any) => ({ ...prev, customColor: e.target.value }))}
                          className="w-8 h-8 rounded cursor-pointer border-0 p-0 bg-transparent"
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Password Setting Section */}
                <div className="flex flex-col gap-3 pt-4 border-t border-white/5">
                  <div className="flex items-center gap-2">
                    <Key size={16} className="text-emerald-400" />
                    <h3 className="text-white text-sm font-semibold tracking-wide">Privacy Firewall</h3>
                  </div>
                  <p className="text-white/50 text-xs">Restrict access to Shiksha Suite with a private password lock.</p>
                  
                  <div className="flex w-full gap-2 mt-1">
                    <input 
                      type="password" 
                      placeholder="Enter protection password" 
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="flex-1 bg-slate-950 border border-white/10 rounded-lg px-3.5 py-2 text-xs text-white outline-none focus:border-emerald-500 transition-colors placeholder:text-white/20"
                    />
                    <button 
                      onClick={handleSavePassword}
                      className="bg-emerald-600/20 hover:bg-emerald-600/40 border border-emerald-500/30 text-emerald-300 px-4 py-2 rounded-lg text-xs transition-all whitespace-nowrap active:scale-95"
                    >
                      Lock
                    </button>
                    <button 
                      onClick={() => {
                        localStorage.removeItem('app_password');
                        setNewPassword('');
                        setSavedMessage(true);
                        setTimeout(() => setSavedMessage(false), 2000);
                      }}
                      className="bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-400 px-3 py-2 rounded-lg text-xs transition-all whitespace-nowrap active:scale-95"
                    >
                      Disable
                    </button>
                  </div>
                  <AnimatePresence>
                    {savedMessage && (
                      <motion.p 
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="text-emerald-400 text-xs mt-1 font-medium"
                      >
                        ✓ Privacy settings modified.
                      </motion.p>
                    )}
                  </AnimatePresence>
                </div>
              </div>
              
              <div className="mt-8 text-center border-t border-white/5 pt-6 pb-2">
                <span className="text-[10px] md:text-xs font-medium tracking-widest uppercase text-white/30">
                  Made by Bhavesh
                </span>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
