import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar, Check, Edit2, MapPin } from 'lucide-react';
import { usePersistentState } from '../lib/usePersistentState';
import { MediaUpload } from './MediaUpload';

const BALLOON_COLORS = [
  '#f472b6', // Pink
  '#38bdf8', // Blue
  '#fbbf24', // Yellow
  '#4ade80', // Green
  '#f87171', // Red
  '#c084fc'  // Purple
];

function BalloonSVG({ size, color }: { size: number; color: string }) {
  return (
    <svg width={size} height={size * 1.6} viewBox="0 0 60 100" fill="none" className="transition-transform duration-300 hover:-translate-y-2">
      <path d="M30 5 C 55 5, 55 35, 40 55 L 35 63 L 25 63 L 20 55 C 5 35, 5 5, 30 5 Z" fill={color} />
      <path d="M18 20 C 18 10, 25 8, 30 8" stroke="rgba(255,255,255,0.5)" strokeWidth="3" strokeLinecap="round" fill="none" />
      <rect x="25" y="63" width="10" height="7" fill="#a0522d" rx="1.5" />
      <path d="M25 66.5 L 35 66.5" stroke="#8b4513" strokeWidth="1" />
      <line x1="30" y1="70" x2="30" y2="100" stroke="rgba(255,255,255,0.8)" strokeWidth="1.5" />
    </svg>
  );
}

const generateInitialMemories = () => {
  const generated = [];
  for (let i = 0; i < 40; i++) {
    const date = new Date(Date.now() - Math.random() * 365 * 24 * 60 * 60 * 1000);
    generated.push({
      id: i + 1,
      left: Math.random() * 3000 - 1500,
      size: Math.random() * 30 + 60,
      delay: Math.random() * 20,
      memory: "",
      date: date.toISOString().split('T')[0],
      color: BALLOON_COLORS[Math.floor(Math.random() * BALLOON_COLORS.length)],
      mediaUrl: null as string | null,
      mediaFile: null as Blob | null,
      mediaType: null as string | null,
      mediaName: null as string | null
    });
  }
  return generated.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

export function MemoryTree() {
  const [memories, setMemories, isLoadedMemories] = usePersistentState('memorytree_data', generateInitialMemories);
  const [activeLeaf, setActiveLeaf, isLoadedActive] = usePersistentState<number | null>('memorytree_active', null);
  const [persistentPan, setPersistentPan, isLoadedPan] = usePersistentState('memorytree_pan', { x: 0 });
  const panRef = useRef({ x: 0 });
  const panContainerRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (isLoadedPan) {
      panRef.current = { ...persistentPan };
      if (panContainerRef.current) {
        panContainerRef.current.style.transform = `translateX(${persistentPan.x}px)`;
      }
    }
  }, [isLoadedPan]);

  const [isPanning, setIsPanning] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const lastPos = useRef({ x: 0 });
  const [searchDate, setSearchDate] = useState("");
  const [highlightId, setHighlightId] = useState<number | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState("");
  const [editDate, setEditDate] = useState("");

  const handlePointerDown = (e: React.PointerEvent) => {
    if (activeLeaf) return;
    setIsPanning(true);
    lastPos.current = { x: e.clientX };
    e.currentTarget.setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isPanning || activeLeaf) return;
    const dx = e.clientX - lastPos.current.x;
    panRef.current.x += dx;
    if (panContainerRef.current) {
      panContainerRef.current.style.transform = `translateX(${panRef.current.x}px)`;
    }
    lastPos.current = { x: e.clientX };
  };

  const handlePointerUp = (e: React.PointerEvent) => { setIsPanning(false); setPersistentPan({ ...panRef.current }); };

  const handleFileUpload = (leafId: number, file: File) => {
    const url = URL.createObjectURL(file);
    setMemories(memories.map(m => m.id === leafId ? { ...m, mediaUrl: url, mediaFile: file, mediaType: file.type, mediaName: file.name } : m));
  };
  
  const goToPresent = () => {
    const saved = memories.filter(m => m.text || m.mediaUrl);
    let target = memories[0];
    if (saved.length > 0) {
      saved.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      target = saved[0];
    }
    panRef.current = { x: -target.left }; 
    setPersistentPan({ x: -target.left }); 
    if (panContainerRef.current) { 
      panContainerRef.current.style.transition = 'transform 0.5s ease'; 
      panContainerRef.current.style.transform = `translateX(${-target.left}px)`; 
      setTimeout(() => { if (panContainerRef.current) panContainerRef.current.style.transition = 'none'; }, 500); 
    }
    if (memories.length > 0) {
      setHighlightId(target.id);
      setTimeout(() => setHighlightId(null), 3000);
    }
  };

  if (!isLoadedMemories || !isLoadedActive || !isLoadedPan) return null;

  return (
    <div 
      className="relative w-full h-[80vh] min-h-[500px] overflow-hidden touch-none select-none bg-transparent"
      ref={containerRef}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
    >
      <div className="absolute top-10 left-1/2 -translate-x-1/2 z-50 pointer-events-auto flex flex-col items-center w-full px-4">
        <div className="bg-white/90 backdrop-blur-md rounded-[2rem] py-4 px-6 md:px-10 border border-sky-100 shadow-xl flex flex-col items-center gap-4 max-w-[320px] w-full">
          <h2 className="text-2xl md:text-3xl font-serif text-slate-800 tracking-wide font-bold">Infinite Sky</h2>
          <div className="flex items-center gap-2 w-full justify-between bg-sky-50 rounded-full px-4 py-2 border border-sky-100">
            <div className="flex items-center gap-2 flex-1">
              <Calendar size={14} className="text-sky-500" />
              <input 
                type="date" 
                value={searchDate} 
                onChange={e => setSearchDate(e.target.value)} 
                className="bg-transparent outline-none text-slate-700 text-sm font-medium w-full" 
              />
            </div>
            <button 
              onClick={() => {
                const target = memories.find(m => m.date === searchDate);
                if (target) {
                  panRef.current = { x: -target.left }; setPersistentPan({ x: -target.left }); if (panContainerRef.current) { panContainerRef.current.style.transition = 'transform 0.5s ease'; panContainerRef.current.style.transform = `translateX(${-target.left}px)`; setTimeout(() => { if (panContainerRef.current) panContainerRef.current.style.transition = 'none'; }, 500); }
                  setHighlightId(target.id);
                  setTimeout(() => setHighlightId(null), 3000);
                }
              }}
              className="bg-[#0ea5e9] text-white px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider shadow-md hover:bg-sky-500 active:scale-95 transition-all ml-2"
            >
              Find
            </button>
          </div>
        </div>
      </div>

      <div ref={panContainerRef} className="absolute inset-0 w-full h-full will-change-transform">
        {memories.map(memory => (
          <div
            key={memory.id}
            className={`absolute cursor-pointer flex flex-col items-center transition-transform duration-300 hover:scale-110 ${highlightId === memory.id ? 'z-40 scale-125' : 'z-10'}`}
            style={{ 
              left: `calc(50% + ${memory.left}px)`, 
              animation: `rise-up-sway ${30 + memory.delay}s linear infinite`,
              animationDelay: `-${(memory.delay / 20) * (30 + memory.delay)}s`
            }}
            onClick={() => { setActiveLeaf(memory.id); setEditValue(memory.memory); setEditDate(memory.date); }}
          >
             <BalloonSVG size={memory.size} color={memory.color} />
<div className={`absolute top-full mt-2 left-1/2 -translate-x-1/2 whitespace-nowrap bg-sky-900/80 px-2 py-0.5 rounded text-[10px] text-sky-100 font-mono transition-opacity pointer-events-none border border-sky-400/30 ${highlightId === memory.id || memory.text || memory.mediaUrl ? 'opacity-100' : 'opacity-0'}`}>{memory.date}</div>
          </div>
        ))}
      </div>
      
      <div className="absolute bottom-6 right-4 md:right-8 z-40 pointer-events-auto">
        <button 
          onClick={goToPresent}
          className="bg-[#0ea5e9] hover:bg-sky-500 text-white rounded-full px-5 py-3 md:px-6 md:py-3.5 font-bold text-[10px] md:text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg transition-all active:scale-95 border-2 border-white/20"
        >
          <MapPin size={16} /> GO TO PRESENT
        </button>
      </div>

      <AnimatePresence>
        {activeLeaf && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.1, ease: "easeOut" }}
            className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm pointer-events-auto"
            onClick={() => { setActiveLeaf(null); setIsEditing(false); }}
          >
            <div className="bg-white p-6 rounded-2xl w-full max-w-md shadow-2xl flex flex-col gap-4" onClick={e => e.stopPropagation()}>
               {(() => {
                 const current = memories.find(m => m.id === activeLeaf)!;
                 return (
                   <>
                     <div className="w-full h-[250px] rounded-lg overflow-hidden border border-slate-200 bg-slate-100">
                       <MediaUpload 
                         mediaUrl={current.mediaUrl}
                         mediaType={current.mediaType}
                         mediaName={current.mediaName}
                         onUpload={(file) => handleFileUpload(current.id, file)}
                         className="w-full h-full"
                       />
                     </div>
                     <div className="flex items-center gap-2 justify-between">
                       <div className="flex items-center gap-2 text-slate-400 text-xs font-mono">
                         <Calendar size={14} />
                         {isEditing ? <input type="date" value={editDate} onChange={e => setEditDate(e.target.value)} className="bg-transparent border-b border-slate-500 outline-none text-slate-800" /> : <span className="text-slate-600">{current.date}</span>}
                       </div>
                       {!isEditing && <Edit2 size={14} className="text-slate-400 cursor-pointer hover:text-slate-700" onClick={() => setIsEditing(true)} />}
                     </div>
                     {isEditing ? (
                       <div className="flex gap-2">
                         <input autoFocus type="text" value={editValue} onChange={e => setEditValue(e.target.value)} onKeyDown={e => e.key === 'Enter' && (setMemories(memories.map(m => m.id === activeLeaf ? { ...m, memory: editValue, date: editDate } : m)), setIsEditing(false))} className="flex-1 bg-slate-50 border border-slate-300 rounded px-3 py-2 text-slate-800 outline-none" placeholder="Add a memory..." />
                         <button onClick={() => { setMemories(memories.map(m => m.id === activeLeaf ? { ...m, memory: editValue, date: editDate } : m)); setIsEditing(false); }} className="bg-[#0ea5e9] hover:bg-sky-500 text-white p-2 rounded"><Check size={18} /></button>
                       </div>
                     ) : (
                       <p className="text-slate-700 text-sm italic font-serif text-center cursor-pointer hover:bg-slate-50 p-2 rounded transition-colors min-h-[40px]" onClick={() => setIsEditing(true)}>{current.memory || "Click to add a memory..."}</p>
                     )}
                   </>
                 );
               })()}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
