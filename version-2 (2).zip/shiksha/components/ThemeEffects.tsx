import React, { useMemo, useEffect } from 'react';

export function ThemeEffects({ theme }: { theme: string }) {
  if (theme === 'shiksha-fall') return <ShikshaFallingEffect />;
  if (theme === 'rainy') return <RainEffect />;
  if (theme === 'winter') return <SnowEffect />;
  if (theme === 'sakura' || theme === 'cherry') return <PetalEffect color="bg-pink-300" />;
  if (theme === 'autumn') return <PetalEffect color="bg-orange-600" />;
  if (theme === 'fireflies') return <FirefliesEffect />;
  if (theme === 'galaxy' || theme === 'aurora') return <StarsEffect />;
  if (theme === 'ocean') return <BubblesEffect />;
  if (theme === 'romantic' || theme === 'pink') return <HeartsEffect />;
  if (theme === 'butterfly') return <ButterflyEffect />;
  if (theme === 'sunset' || theme === 'golden') return <LightRaysEffect />;
  if (theme === 'nature') return <PetalEffect color="bg-emerald-600" />;
  
  return null;
}

const RainEffect = () => {
  const drops = useMemo(() => Array.from({ length: 40 }).map((_, i) => ({
    id: i,
    left: `${Math.random() * 100}%`,
    duration: Math.random() * 0.5 + 0.5,
    delay: Math.random() * 2,
    opacity: Math.random() * 0.4 + 0.2,
  })), []);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-[0]">
      <style>{`
        @keyframes fallRain {
          0% { transform: translate(0, -10vh); opacity: var(--start-opacity); }
          100% { transform: translate(-5px, 110vh); opacity: 0.1; }
        }
      `}</style>
      {drops.map((style) => (
        <div
          key={style.id}
          className="absolute top-0 w-[2px] h-[30px] bg-blue-200/60 rounded-full"
          style={{
            left: style.left,
            '--start-opacity': style.opacity,
            animation: `fallRain ${style.duration}s linear ${style.delay}s infinite`,
          } as React.CSSProperties}
        />
      ))}
    </div>
  );
};

const SnowEffect = () => {
  const flakes = useMemo(() => Array.from({ length: 40 }).map((_, i) => ({
    id: i,
    left: `${Math.random() * 100}%`,
    duration: Math.random() * 10 + 10,
    delay: Math.random() * 5,
    opacity: Math.random() * 0.8 + 0.2,
    size: Math.random() * 6 + 4,
    xOffset: Math.random() * 100 - 50,
  })), []);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-[0]">
      <style>{`
        @keyframes fallSnow {
          0% { transform: translate(0, -10vh) rotate(0deg); }
          50% { transform: translate(var(--x-half), 50vh) rotate(180deg); }
          100% { transform: translate(var(--x-end), 110vh) rotate(360deg); }
        }
      `}</style>
      {flakes.map((style) => (
        <div
          key={style.id}
          className="absolute top-0 bg-white rounded-full blur-[1px] will-change-transform"
          style={{
            left: style.left,
            opacity: style.opacity,
            width: style.size,
            height: style.size,
            '--x-half': `${style.xOffset / 2}px`,
            '--x-end': `${style.xOffset}px`,
            animation: `fallSnow ${style.duration}s linear ${style.delay}s infinite`,
          } as React.CSSProperties}
        />
      ))}
    </div>
  );
};

const PetalEffect = ({ color }: { color: string }) => {
  const petals = useMemo(() => Array.from({ length: 30 }).map((_, i) => ({
    id: i,
    left: `${Math.random() * 100}%`,
    duration: Math.random() * 8 + 8,
    delay: Math.random() * 5,
    opacity: Math.random() * 0.6 + 0.4,
    xOffset: Math.random() * 100 - 50,
    rotateEnd: Math.random() * 360 + 360,
  })), []);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-[0]">
       <style>{`
        @keyframes fallPetal {
          0% { transform: translate(0, -10vh) rotate(0deg); }
          33% { transform: translate(var(--x-1), 30vh) rotate(120deg); }
          66% { transform: translate(var(--x-2), 70vh) rotate(240deg); }
          100% { transform: translate(var(--x-3), 110vh) rotate(var(--r-end)); }
        }
      `}</style>
      {petals.map((style) => (
        <div
          key={style.id}
          className={`absolute top-0 w-3 h-3 ${color} rounded-tl-full rounded-br-full blur-[1px] will-change-transform`}
          style={{
            left: style.left,
            opacity: style.opacity,
            '--x-1': `${style.xOffset / 2}px`,
            '--x-2': `${-style.xOffset / 2}px`,
            '--x-3': `${style.xOffset}px`,
            '--r-end': `${style.rotateEnd}deg`,
            animation: `fallPetal ${style.duration}s ease-in-out ${style.delay}s infinite`,
          } as React.CSSProperties}
        />
      ))}
    </div>
  );
};

const FirefliesEffect = () => {
  const flies = useMemo(() => Array.from({ length: 30 }).map((_, i) => ({
    id: i,
    left: `${Math.random() * 100}%`,
    top: `${Math.random() * 100}%`,
    duration: Math.random() * 4 + 3,
    delay: Math.random() * 4,
    x1: Math.random() * 40 - 20,
    y1: Math.random() * 40 - 20,
    x2: Math.random() * 40 - 20,
    y2: Math.random() * 40 - 20,
  })), []);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-[0]">
       <style>{`
        @keyframes flyFirefly {
          0% { transform: translate(0, 0) scale(0.8); opacity: 0; }
          25% { transform: translate(var(--x1), var(--y1)) scale(1.2); opacity: 1; }
          50% { transform: translate(var(--x2), var(--y2)) scale(0.9); opacity: 0.8; }
          75% { transform: translate(var(--x1), var(--y1)) scale(1.1); opacity: 1; }
          100% { transform: translate(0, 0) scale(0.8); opacity: 0; }
        }
      `}</style>
      {flies.map((style) => (
        <div
          key={style.id}
          className="absolute w-1.5 h-1.5 bg-yellow-300 rounded-full shadow-[0_0_10px_rgba(253,224,71,0.8)] will-change-transform"
          style={{
            left: style.left,
            top: style.top,
            '--x1': `${style.x1}px`,
            '--y1': `${style.y1}px`,
            '--x2': `${style.x2}px`,
            '--y2': `${style.y2}px`,
            animation: `flyFirefly ${style.duration}s ease-in-out ${style.delay}s infinite`,
          } as React.CSSProperties}
        />
      ))}
    </div>
  );
};

const StarsEffect = () => {
  const stars = useMemo(() => Array.from({ length: 40 }).map((_, i) => ({
    id: i,
    left: `${Math.random() * 100}%`,
    top: `${Math.random() * 100}%`,
    duration: Math.random() * 3 + 2,
    delay: Math.random() * 3,
    size: Math.random() * 3 + 1,
  })), []);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-[0]">
       <style>{`
        @keyframes twinkleStar {
          0%, 100% { transform: scale(0.8); opacity: 0.2; }
          50% { transform: scale(1.2); opacity: 1; }
        }
      `}</style>
      {stars.map((style) => (
        <div
          key={style.id}
          className="absolute bg-white rounded-full will-change-transform"
          style={{
            left: style.left,
            top: style.top,
            width: style.size,
            height: style.size,
            animation: `twinkleStar ${style.duration}s ease-in-out ${style.delay}s infinite`,
          } as React.CSSProperties}
        />
      ))}
    </div>
  );
};

const BubblesEffect = () => {
  const bubbles = useMemo(() => Array.from({ length: 20 }).map((_, i) => ({
    id: i,
    left: `${Math.random() * 100}%`,
    duration: Math.random() * 8 + 6,
    delay: Math.random() * 5,
    size: Math.random() * 15 + 5,
    xOffset: Math.random() * 60 - 30,
  })), []);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-[0]">
       <style>{`
        @keyframes floatBubble {
          0% { transform: translate(0, 10vh) scale(1); opacity: 0; }
          25% { opacity: 1; }
          75% { opacity: 1; }
          100% { transform: translate(var(--x-off), -110vh) scale(1.5); opacity: 0; }
        }
      `}</style>
      {bubbles.map((style) => (
        <div
          key={style.id}
          className="absolute bottom-0 rounded-full border border-white/40 bg-white/10 will-change-transform"
          style={{
            left: style.left,
            width: style.size,
            height: style.size,
            '--x-off': `${style.xOffset}px`,
            animation: `floatBubble ${style.duration}s ease-in-out ${style.delay}s infinite`,
          } as React.CSSProperties}
        />
      ))}
    </div>
  );
};

const HeartsEffect = () => {
  const hearts = useMemo(() => Array.from({ length: 15 }).map((_, i) => ({
    id: i,
    left: `${Math.random() * 100}%`,
    duration: Math.random() * 10 + 8,
    delay: Math.random() * 5,
    scale: Math.random() * 0.5 + 0.5,
    xOffset: Math.random() * 100 - 50,
  })), []);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-[0]">
       <style>{`
        @keyframes floatHeart {
          0% { transform: translate(0, 10vh) scale(var(--s)); opacity: 0; }
          25% { opacity: 1; }
          75% { opacity: 1; }
          100% { transform: translate(var(--x-off), -110vh) scale(var(--s)); opacity: 0; }
        }
      `}</style>
      {hearts.map((style) => (
        <div
          key={style.id}
          className="absolute bottom-0 text-pink-400/40 will-change-transform"
          style={{
            left: style.left,
            '--s': style.scale,
            '--x-off': `${style.xOffset}px`,
            animation: `floatHeart ${style.duration}s ease-in-out ${style.delay}s infinite`,
          } as React.CSSProperties}
        >
          <svg viewBox="0 0 24 24" fill="currentColor" className="w-8 h-8">
            <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
          </svg>
        </div>
      ))}
    </div>
  );
};

const ButterflyEffect = () => {
  const butterflies = useMemo(() => Array.from({ length: 12 }).map((_, i) => ({
    id: i,
    left: `${Math.random() * 100}%`,
    duration: Math.random() * 12 + 10,
    delay: Math.random() * 5,
    scale: Math.random() * 0.5 + 0.5,
    xOffset: Math.random() * 150 - 75,
  })), []);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-[0]">
       <style>{`
        @keyframes floatButterfly {
          0% { transform: translate(0, 10vh) scale(var(--s)); opacity: 0; }
          25% { opacity: 1; }
          75% { opacity: 1; }
          100% { transform: translate(var(--x-off), -110vh) scale(var(--s)); opacity: 0; }
        }
      `}</style>
      {butterflies.map((style) => (
        <div
          key={style.id}
          className="absolute bottom-0 text-emerald-400/50 will-change-transform"
          style={{
            left: style.left,
            '--s': style.scale,
            '--x-off': `${style.xOffset}px`,
            animation: `floatButterfly ${style.duration}s ease-in-out ${style.delay}s infinite`,
          } as React.CSSProperties}
        >
          <svg viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
            <path d="M12 10.999L9.423 8.423A3.003 3.003 0 0113.666 4.18l.834.834.834-.834A3.003 3.003 0 0119.577 8.42L17 11V13l2.577 2.577a3.003 3.003 0 01-4.243 4.243l-.834-.834-.834.834a3.003 3.003 0 01-4.243-4.243L12 13.001v-2.002zM10.834 5.594A1.001 1.001 0 009.42 7.008l1.414 1.414 1.414-1.414-1.414-1.414z"/>
          </svg>
        </div>
      ))}
    </div>
  );
};

const LightRaysEffect = () => {
  const rays = useMemo(() => Array.from({ length: 6 }).map((_, i) => ({
    id: i,
    left: `${Math.random() * 100}%`,
    duration: Math.random() * 8 + 5,
    delay: Math.random() * 2,
    opacity: Math.random() * 0.2 + 0.1,
    width: Math.random() * 100 + 50,
  })), []);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-[0]">
       <style>{`
        @keyframes shimmerRay {
          0%, 100% { opacity: var(--o-half); transform: scaleX(0.8) skewX(-20deg); }
          50% { opacity: var(--o-full); transform: scaleX(1.2) skewX(-20deg); }
        }
      `}</style>
      {rays.map((style) => (
        <div
          key={style.id}
          className="absolute top-0 bottom-0 bg-gradient-to-b from-white/30 to-transparent blur-[20px] origin-top will-change-transform"
          style={{
            left: style.left,
            width: style.width,
            '--o-half': style.opacity * 0.5,
            '--o-full': style.opacity,
            animation: `shimmerRay ${style.duration}s ease-in-out ${style.delay}s infinite`,
          } as React.CSSProperties}
        />
      ))}
    </div>
  );
};


const ShikshaFallingEffect = () => {
  const NEON_COLORS = [
    { start: '#ff007f', glow: '#ff1493' }, // Pink
    { start: '#00e5ff', glow: '#00ffff' }, // Cyan
    { start: '#39ff14', glow: '#32cd32' }, // Green
    { start: '#8a2be2', glow: '#9370db' }, // Purple
    { start: '#ff5e00', glow: '#ff8c00' }, // Orange
    { start: '#ffff00', glow: '#ffea00' }  // Yellow
  ];

  const items = useMemo(() => Array.from({ length: 5 }).map((_, i) => {
    const colorPair = NEON_COLORS[Math.floor(Math.random() * NEON_COLORS.length)];
    return {
      id: i,
      left: `${5 + (i * 15) + Math.random() * 5}%`,
      delay: Math.random() * -30, // Negative delay so they are immediately on screen
      duration: Math.random() * 15 + 20,
      scale: Math.random() * 0.3 + 0.5,
      colorStart: colorPair.start,
      glowColor: colorPair.glow,
    }
  }), []);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-[0]">
       <style>{`
        @keyframes firefly-float {
          0% { transform: translate(0, 0); }
          100% { transform: translate(100px, -100px); }
        }
        @keyframes shiksha-fall {
          0% { transform: translateY(-20vh) scale(var(--s)); }
          100% { transform: translateY(120vh) scale(var(--s)); }
        }
      `}</style>
      <div className="absolute inset-0 opacity-40">
        {[...Array(20)].map((_, i) => (
          <div key={i} className="absolute rounded-full bg-cyan-200 will-change-transform" style={{
            width: Math.random() * 4 + 1 + 'px',
            height: Math.random() * 4 + 1 + 'px',
            left: Math.random() * 100 + '%',
            top: Math.random() * 100 + '%',
            opacity: Math.random() * 0.5 + 0.2,
            animation: `firefly-float ${10 + Math.random() * 10}s ease-in-out infinite alternate`
          }} />
        ))}
      </div>
      {items.map((style) => (
        <div
          key={style.id}
          className="absolute flex flex-col items-center will-change-transform"
          style={{ 
            left: style.left,
            '--s': style.scale,
            animation: `shiksha-fall ${style.duration}s linear ${style.delay}s infinite`,
          } as React.CSSProperties}
        >
          <span 
             className="text-xl md:text-2xl font-black tracking-wider uppercase drop-shadow-2xl"
             style={{
               color: style.colorStart,
               textShadow: `0 0 10px ${style.colorStart}, 0 0 20px ${style.glowColor}, 0 0 40px ${style.glowColor}`
             }}
          >
             SHIKSHA
          </span>
        </div>
      ))}
    </div>
  );
};

