import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar, Edit2, Check, RotateCcw, Heart, Star, Camera, Coffee } from 'lucide-react';
import { usePersistentState } from '../lib/usePersistentState';
import { MediaUpload } from './MediaUpload';

// Beautiful pastel paper styles for pages
const paperStyles = [
  { bg: '#ff007f', border: '#ff66b2', text: 'text-white', noteBg: '#cc0066', tape: 'bg-white/50' },
  { bg: '#00e5ff', border: '#66ffff', text: 'text-black', noteBg: '#00b2cc', tape: 'bg-white/50' },
  { bg: '#39ff14', border: '#99ff80', text: 'text-black', noteBg: '#2ecc10', tape: 'bg-white/50' },
  { bg: '#8a2be2', border: '#b266ff', text: 'text-white', noteBg: '#6a1baf', tape: 'bg-white/50' },
  { bg: '#ffff00', border: '#ffff66', text: 'text-black', noteBg: '#cccc00', tape: 'bg-white/50' },
];

// SVG stickers for scrapbooking touch
function SweetSticker({ type, className }: { type: string; className?: string }) {
  switch (type) {
    case 'heart':
      return (
        <div className={`absolute select-none pointer-events-none filter drop-shadow-[0_2px_4px_rgba(236,72,153,0.3)] ${className}`}>
          <Heart size={20} fill="#f43f5e" className="text-rose-600 animate-[bounce_3s_infinite]" />
        </div>
      );
    case 'star':
      return (
        <div className={`absolute select-none pointer-events-none filter drop-shadow-[0_2px_4px_rgba(234,179,8,0.3)] ${className}`}>
          <Star size={18} fill="#fbbf24" className="text-amber-500 animate-[pulse_2s_infinite]" />
        </div>
      );
    case 'camera':
      return (
        <div className={`absolute select-none pointer-events-none filter drop-shadow-[0_3px_5px_rgba(0,0,0,0.15)] bg-slate-100 border border-slate-300 p-1.5 rounded rotate-[-8deg] ${className}`}>
          <Camera size={14} className="text-slate-600" />
        </div>
      );
    case 'coffee':
      return (
        <div className={`absolute select-none pointer-events-none filter drop-shadow-[0_2px_4px_rgba(120,53,4,0.2)] bg-amber-50 border border-amber-200 p-1.5 rounded-full rotate-[12deg] ${className}`}>
          <Coffee size={13} className="text-amber-700" />
        </div>
      );
    default:
      return null;
  }
}

const createPhotoAt = (id: number, offsetDays: number) => {
  const date = new Date(Date.now() - offsetDays * 24 * 60 * 60 * 1000);
  return {
    id,
    rotation: Math.random() * 10 - 5, // gentle soft rotational tilt
    scale: 0.95 + Math.random() * 0.1,
    caption: "", // strictly empty initial captions
    date: date.toISOString().split('T')[0],
    isLandscape: Math.random() > 0.5,
    mediaUrl: null as string | null,
    mediaFile: null as Blob | null,
    mediaType: null as string | null,
    mediaName: null as string | null
  };
};

const generateInitialPhotos = () => {
  const generated = [];
  for (let i = 0; i < 20; i++) {
    generated.push(createPhotoAt(i + 1, i * 6 + Math.random() * 3));
  }
  return generated;
};

export function Scrapbook() {
  const [photos, setPhotos, isLoaded] = usePersistentState('scrapbook_photos', generateInitialPhotos);
  const [currentIndex, setCurrentIndex] = usePersistentState('scrapbook_index', 0);
  const [direction, setDirection] = useState(0);

  const [editingId, setEditingId] = useState<number | null>(null);
  const [editValue, setEditValue] = useState("");
  const [editDate, setEditDate] = useState("");

  const handleEditNote = (photoId: number, currentNote: string, currentDate: string) => {
    setEditingId(photoId);
    setEditValue(currentNote);
    setEditDate(currentDate);
  };

  const handleSaveNote = (photoId: number) => {
    setPhotos(photos.map(p => p.id === photoId ? { ...p, caption: editValue, date: editDate } : p));
    setEditingId(null);
  };

  const handleFileUpload = (photoId: number, file: File) => {
    const url = URL.createObjectURL(file);
    setPhotos(photos.map(p => p.id === photoId ? { ...p, mediaUrl: url, mediaFile: file, mediaType: file.type, mediaName: file.name } : p));
  };

  const next = () => {
    setDirection(1);
    setEditingId(null);
    
    // INFINITE SCRAPBOOK TRIGGER
    // If approaching the end of existing photos, append 10 more pages back in time!
    if (currentIndex >= photos.length - 2) {
      setPhotos(prev => {
        const nextList = [...prev];
        const startId = prev.length + 1;
        for (let i = 0; i < 10; i++) {
          nextList.push(createPhotoAt(startId + i, (prev.length + i) * 6 + Math.random() * 3));
        }
        return nextList;
      });
    }

    setCurrentIndex(prev => (prev + 1) % (photos.length + 10)); // bounds-safe modulo
  };

  const prev = () => {
    setDirection(-1);
    setEditingId(null);
    setCurrentIndex(prev => (prev - 1 + photos.length) % photos.length);
  };

  const goToPresent = () => {
    setDirection(-1);
    
    // Find latest saved item
    const saved = photos.filter(p => p.caption || p.mediaUrl);
    let targetIndex = 0;
    if (saved.length > 0) {
      saved.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      targetIndex = photos.findIndex(p => p.id === saved[0].id);
      if (targetIndex === -1) targetIndex = 0;
    }
    
    setCurrentIndex(targetIndex);
    setEditingId(null);
  };

  const currentPhoto = photos[currentIndex] || photos[0];
  const currentPaper = paperStyles[currentIndex % paperStyles.length];

  const variants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 450 : -450,
      opacity: 0,
      rotateY: direction > 0 ? 60 : -60,
      scale: 0.85
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1,
      rotateY: 0,
      scale: 1
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 450 : -450,
      opacity: 0,
      rotateY: direction < 0 ? 60 : -60,
      scale: 0.85
    })
  };

  if (!isLoaded) return null;

  return (
    <div className="relative w-full max-w-4xl mx-auto h-[70vh] min-h-[500px] flex flex-col items-center justify-center perspective-[1500px]">
      
      {/* Header with Go To Present */}
      <div className="absolute top-0 w-full flex justify-between items-center px-4 md:px-12 z-50">
        <div className="flex flex-col gap-1 items-start">
          <h2 className="text-xl md:text-2xl text-white drop-shadow-[0_0_10px_rgba(255,0,127,0.8)] font-serif tracking-widest">The Scrapbook</h2>
          <div className="text-[10px] text-pink-200/80 uppercase tracking-[0.2em] font-mono">Infinite Page Layouts</div>
        </div>

        <div className="flex items-center gap-2.5">
          {currentIndex > 0 && (
            <button 
              onClick={goToPresent}
              className="bg-pink-600/60 hover:bg-pink-500/80 text-white border-2 border-pink-400 rounded-full px-4 py-1.5 text-xs font-bold transition-all active:scale-95 flex items-center gap-1 shadow-[0_0_15px_rgba(255,0,127,0.6)] hover:shadow-[0_0_25px_rgba(255,0,127,1)] hover:scale-105 drop-shadow-[0_0_8px_rgba(255,0,127,1)] uppercase tracking-wide pointer-events-auto"
            >
              <RotateCcw size={11} />
              <span>Go to Present</span>
            </button>
          )}

          <div className="text-pink-300 drop-shadow-[0_0_8px_rgba(255,0,127,0.8)] font-mono text-xs border border-pink-500/40 px-3.5 py-1.5 rounded-full bg-pink-900/40 backdrop-blur-md">
            Page {currentIndex + 1}
          </div>
        </div>
      </div>

      <AnimatePresence initial={false} custom={direction}>
        <motion.div
          key={currentIndex}
          custom={direction}
          variants={variants}
          initial="enter"
          animate="center"
          exit="exit"
          transition={{ 
            x: { type: "spring", stiffness: 280, damping: 28 }, 
            opacity: { duration: 0.15 }, 
            rotateY: { duration: 0.38 } 
          }}
          className="absolute"
        >
          {/* Beautiful double-layered paper shadow card */}
          <div 
            className={`relative p-5 pb-14 md:p-6 md:pb-16 rounded-lg border transition-colors duration-300 ${currentPhoto.isLandscape ? 'w-[310px] md:w-[520px] h-[240px] md:h-[370px]' : 'w-[250px] md:w-[370px] h-[340px] md:h-[480px]'}`}
            style={{ rotate: `${currentPhoto.rotation}deg`, backgroundColor: currentPaper.bg, borderColor: currentPaper.border, boxShadow: `0 0 50px 10px ${currentPaper.bg}, inset 0 0 20px ${currentPaper.border}` }}
          >
            {/* Real Tape strip decoration on photo corners */}
            <div className={`absolute -top-3.5 left-1/2 -translate-x-1/2 w-20 h-5.5 ${currentPaper.tape} backdrop-blur-[1.5px] border-x border-dashed border-black/5 rotate-2 shadow-sm pointer-events-none z-40`} style={{ mixBlendMode: 'multiply' }} />

            {/* Visual Stickers */}
            <SweetSticker type="heart" className="-top-3 -right-3" />
            <SweetSticker type="star" className="-bottom-3 -left-2" />
            {currentIndex % 3 === 0 && <SweetSticker type="camera" className="top-12 -left-6" />}
            {currentIndex % 3 === 1 && <SweetSticker type="coffee" className="bottom-14 -right-5" />}

            {/* Inner photo container */}
            <div className="w-full h-[82%] bg-slate-200 border border-slate-300 shadow-inner overflow-hidden relative group rounded">
               <MediaUpload 
                 mediaUrl={currentPhoto.mediaUrl}
                 mediaType={currentPhoto.mediaType}
                 mediaName={currentPhoto.mediaName}
                 onUpload={(file) => handleFileUpload(currentPhoto.id, file)}
                 className="w-full h-full"
               />
            </div>
            
            {/* Timestamp date layout */}
            <div className="absolute bottom-3 left-4 text-slate-500 font-mono text-[10px] md:text-xs flex items-center gap-1.5 opacity-75 pointer-events-auto z-10">
              <Calendar size={12} />
              {editingId === currentPhoto.id ? (
                <input 
                  type="date"
                  value={editDate}
                  onChange={e => setEditDate(e.target.value)}
                  className="bg-transparent border-b border-slate-300 outline-none w-20 text-[9px]"
                />
              ) : (
                currentPhoto.date
              )}
            </div>

            {/* Interactive Note Caption */}
            {editingId === currentPhoto.id ? (
              <div className="absolute bottom-3.5 pl-28 pr-4 flex items-center gap-1 w-full justify-end z-10">
                <input 
                  autoFocus
                  type="text"
                  placeholder="Caption..."
                  value={editValue}
                  onChange={e => setEditValue(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleSaveNote(currentPhoto.id)}
                  className="flex-1 text-center font-serif text-xs md:text-sm text-slate-800 italic tracking-wide px-1 bg-slate-100/85 border-b border-slate-400 outline-none rounded py-1"
                />
                <button onClick={() => handleSaveNote(currentPhoto.id)} className="text-emerald-700 p-1 hover:bg-emerald-100 active:scale-90 transition-all rounded shrink-0">
                  <Check size={14} />
                </button>
              </div>
            ) : (
              <p 
                className="absolute bottom-3 left-0 right-0 text-center font-serif text-xs md:text-sm text-slate-800 italic tracking-wide px-4 truncate cursor-pointer hover:bg-black/5 mx-12 rounded py-1 transition-colors group flex items-center justify-center gap-1.5"
                onClick={(e) => { e.stopPropagation(); handleEditNote(currentPhoto.id, currentPhoto.caption, currentPhoto.date); }}
                title="Click to edit caption"
              >
                <span>{currentPhoto.caption || <span className="text-slate-400/60 not-italic text-xs">Click to write photo caption...</span>}</span>
                <Edit2 size={11} className="opacity-0 group-hover:opacity-40 text-slate-600 shrink-0" />
              </p>
            )}

            <div className="absolute -top-3 -left-3 w-8 h-8 opacity-25 mix-blend-multiply pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle, #000 1.2px, transparent 1.2px)', backgroundSize: '4px 4px' }} />
            <div className="absolute -bottom-3 -right-3 w-8 h-8 opacity-25 mix-blend-multiply pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle, #000 1.2px, transparent 1.2px)', backgroundSize: '4px 4px' }} />
          </div>
        </motion.div>
      </AnimatePresence>

      <div className="absolute bottom-0 w-full flex justify-center gap-12 z-50">
        <button onClick={prev} className="bg-pink-600/30 hover:bg-pink-500/50 shadow-[0_0_20px_rgba(255,0,127,0.7)] hover:shadow-[0_0_30px_rgba(255,0,127,1)] active:bg-pink-400 active:scale-95 backdrop-blur-md text-white border-2 border-pink-400 px-6 py-2.5 rounded-full uppercase tracking-widest text-xs font-bold transition-all hover:px-8 hover:scale-105 duration-300 drop-shadow-[0_0_10px_rgba(255,0,127,1)]">
          Prev Polaroid
        </button>
        <button onClick={next} className="bg-pink-600/30 hover:bg-pink-500/50 shadow-[0_0_20px_rgba(255,0,127,0.7)] hover:shadow-[0_0_30px_rgba(255,0,127,1)] active:bg-pink-400 active:scale-95 backdrop-blur-md text-white border-2 border-pink-400 px-6 py-2.5 rounded-full uppercase tracking-widest text-xs font-bold transition-all hover:px-8 hover:scale-105 duration-300 drop-shadow-[0_0_10px_rgba(255,0,127,1)]">
          Next Polaroid
        </button>
      </div>
    </div>
  );
}
