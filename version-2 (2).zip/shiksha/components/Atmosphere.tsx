export function Atmosphere() {
  return (
    <div className="fixed inset-0 pointer-events-none z-[0] overflow-hidden">
      <style>{`
        @keyframes shift-gradient {
          0% { background: linear-gradient(to bottom, #1e1b4b, #312e81, #000000); }
          50% { background: linear-gradient(to bottom, #7c2d12, #9d174d, #1e1b4b); }
          100% { background: linear-gradient(to bottom, #1e1b4b, #312e81, #000000); }
        }
        .animate-shift-gradient {
          animation: shift-gradient 30s linear infinite;
        }
        @keyframes firefly-float {
          0% { transform: translateY(0) translateX(0); opacity: 0; }
          20% { opacity: 0.8; }
          80% { opacity: 0.6; }
          100% { transform: translateY(-200px) translateX(30px); opacity: 0; }
        }
        @keyframes petal-fall {
          0% { transform: translateY(-5vh) translateX(0) rotate(0deg); opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { transform: translateY(110vh) translateX(100px) rotate(360deg); opacity: 0; }
        }
      `}</style>
      
      {/* Shifting Gradient */}
      <div className="absolute inset-0 opacity-70 animate-shift-gradient" />
      
      {/* Fireflies */}
      {[...Array(25)].map((_, i) => (
        <div
          key={`firefly-${i}`}
          className="absolute rounded-full bg-amber-200"
          style={{
            width: Math.random() * 4 + 2 + 'px',
            height: Math.random() * 4 + 2 + 'px',
            boxShadow: '0 0 12px 3px rgba(253,224,71,0.6)',
            top: Math.random() * 100 + '%',
            left: Math.random() * 100 + '%',
            animation: `firefly-float ${Math.random() * 12 + 10}s ease-in-out ${Math.random() * 10}s infinite`
          }}
        />
      ))}
      
      {/* Cherry Blossoms */}
      {[...Array(15)].map((_, i) => (
        <div
          key={`petal-${i}`}
          className="absolute bg-pink-300/30 rounded-full blur-[1px]"
          style={{
            width: Math.random() * 12 + 6 + 'px',
            height: Math.random() * 8 + 4 + 'px',
            top: -20,
            left: Math.random() * 100 + '%',
            borderRadius: '50% 0 50% 0',
            animation: `petal-fall ${Math.random() * 15 + 15}s linear ${Math.random() * 15}s infinite`
          }}
        />
      ))}
    </div>
  );
}

