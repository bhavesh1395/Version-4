import { useState, useEffect, useRef } from 'react';
import { store } from './db';

// Helper to deeply convert Files/Blobs to Object URLs when loading from DB
// And to keep track of the files so we can save them back
export function usePersistentState<T>(key: string, initialValue: T | (() => T)) {
  const [state, setState] = useState<T>(initialValue);
  const [isLoaded, setIsLoaded] = useState(false);
  const isFirstMount = useRef(true);

  // Load from localforage
  useEffect(() => {
    store.getItem<T>(key).then((val) => {
      if (val !== null) {
        // Need to recreate object URLs for any blobs in the state
        const restoreUrls = (obj: any): any => {
          if (!obj) return obj;
          if (Array.isArray(obj)) return obj.map(restoreUrls);
          if (typeof obj === 'object') {
            const newObj = { ...obj };
            // Clear any previously uploaded photo / media
            if ('mediaFile' in newObj) newObj.mediaFile = null;
            if ('mediaUrl' in newObj) newObj.mediaUrl = null;
            if ('mediaType' in newObj) newObj.mediaType = null;
            if ('mediaName' in newObj) newObj.mediaName = null;
            
            for (const k in newObj) {
              if (Array.isArray(newObj[k]) || (typeof newObj[k] === 'object' && newObj[k] !== null && !(newObj[k] instanceof Blob))) {
                newObj[k] = restoreUrls(newObj[k]);
              }
            }
            return newObj;
          }
          return obj;
        };
        
        setState(restoreUrls(val));
      }
      setIsLoaded(true);
    });
  }, [key]);

  // Save to localforage
  useEffect(() => {
    if (isFirstMount.current) {
      isFirstMount.current = false;
      return;
    }
    if (isLoaded) {
      // We don't want to save the object URLs, they are ephemeral.
      // But we can just save the whole object because object URLs are just strings.
      // The Blobs are in `mediaFile`, which localforage will save.
      store.setItem(key, state);
    }
  }, [key, state, isLoaded]);

  return [state, setState, isLoaded] as const;
}
