import { Atmosphere } from "./components/Atmosphere";
import { Constellation } from "./components/Constellation";
import { Lanterns } from "./components/Lanterns";
import { MemoryTree } from "./components/MemoryTree";
import { Scrapbook } from "./components/Scrapbook";
import { ApologyLetter } from "./components/ApologyLetter";
import { Garden } from "./components/Garden";

import { GrandEntrance } from "./components/GrandEntrance";
import { CursorButterflies } from "./components/CursorButterflies";
import { SettingsMenu } from "./components/SettingsMenu";
import { LoginScreen } from "./components/LoginScreen";
import { ThemeEffects } from "./components/ThemeEffects";
import { getCustomSong } from "./lib/indexedDbHelper";
import { Music, VolumeX, ArrowLeft, Sparkles, Cloud, Flame, BookOpen, Flower2, Heart } from "lucide-react";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { PLAYLIST } from "./songs";

function getYoutubeId(url?: string) {
  if (!url) return null;
  const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
  const match = url.match(regExp);
  return (match && match[2].length === 11) ? match[2] : null;
}

export default function App() {
  const [isAudioMuted, setIsAudioMuted] = useState(true);
  const [selectedTheme, setSelectedTheme] = useState<string | null>(null);
  const [hasEntered, setHasEntered] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [savedPassword, setSavedPassword] = useState<string | null>(null);
  const [customSongUrl, setCustomSongUrl] = useState<string | null>(null);
  
  const [settings, setSettings] = useState(() => {
    const saved = localStorage.getItem('shiksha_settings');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (!parsed.youtubeUrls) parsed.youtubeUrls = [];
        return parsed;
      } catch (e) {}
    }
    return {
      cursorButterflies: true,
      atmosphere: true,
      songId: PLAYLIST[0]?.id || '',
      appTheme: 'default',
      youtubeUrls: [],
    };
  });

  useEffect(() => {
    localStorage.setItem('shiksha_settings', JSON.stringify(settings));
  }, [settings]);

  // Load custom song Blob from IndexedDB dynamically when selected
  useEffect(() => {
    if (settings.songId?.startsWith('custom_')) {
      getCustomSong(settings.songId).then(song => {
        if (song) {
          const url = URL.createObjectURL(song.blob);
          setCustomSongUrl(url);
        } else {
          setCustomSongUrl(null);
        }
      }).catch(e => {
        console.error(e);
        setCustomSongUrl(null);
      });
    } else {
      if (customSongUrl) {
        URL.revokeObjectURL(customSongUrl);
      }
      setCustomSongUrl(null);
    }
  }, [settings.songId]);

  const currentSongUrl = settings.songId?.startsWith('custom_')
    ? customSongUrl 
    : PLAYLIST.find(s => s.id === settings.songId)?.url;

  const currentYoutubeUrl = settings.songId?.startsWith('youtube_')
    ? settings.youtubeUrls?.find((y: any) => y.id === settings.songId)?.url || settings.youtubeUrl
    : settings.songId === 'youtube' ? settings.youtubeUrl : null;

  const getThemeClasses = (theme: string) => {
    switch (theme) {
      case 'custom': return '';
      // Original core themes
      case 'romantic': return 'bg-rose-950 bg-[url("https://images.unsplash.com/photo-1518199266791-5375a83164ba?q=80&w=2070&auto=format&fit=crop")] bg-cover bg-fixed animate-slow-pan';
      case 'nature': return 'bg-sky-950 bg-[url("https://images.unsplash.com/photo-1441974231531-c6227db76b6e?q=80&w=2071&auto=format&fit=crop")] bg-cover bg-fixed animate-slow-pan';
      case 'galaxy': return 'bg-slate-950 bg-[url("https://images.unsplash.com/photo-1462331940025-496dfbfc7564?q=80&w=2048&auto=format&fit=crop")] bg-cover bg-fixed animate-slow-pan';
      case 'realistic': return 'bg-stone-900 bg-[url("https://images.unsplash.com/photo-1475924156734-496f6cac6ec1?q=80&w=2070&auto=format&fit=crop")] bg-cover bg-fixed animate-slow-pan';
      
      // Beautiful Premium New Themes
      case 'shiksha-fall': return 'bg-[#050510] bg-[radial-gradient(circle_at_center,_#100b1f_0%,_#05020a_100%)]';
      case 'sakura': return 'bg-gradient-to-br from-[#fff1f2] via-[#ffe4e6] via-[#fecdd3] to-[#fda4af] animate-slow-pan-gradient';
      case 'lavender': return 'bg-gradient-to-br from-[#faf5ff] via-[#f3e8ff] via-[#e9d5ff] to-[#d8b4fe] animate-slow-pan-gradient';
      case 'sunset': return 'bg-gradient-to-br from-[#fff7ed] via-[#ffedd5] via-[#fed7aa] via-[#fdba74] via-[#f97316] to-[#ea580c] animate-slow-pan-gradient';
      case 'aurora': return 'bg-gradient-to-br from-[#020617] via-[#0d9488] via-[#0284c7] via-[#4f46e5] to-[#020617] animate-slow-pan-gradient';
      case 'rainy': return 'bg-gradient-to-b from-[#0f172a] via-[#1e293b] to-[#0f172a] animate-slow-pan-gradient';
      case 'autumn': return 'bg-gradient-to-br from-[#451a03] via-[#78350f] via-[#9a3412] to-[#451a03] animate-slow-pan-gradient';
      case 'winter': return 'bg-gradient-to-br from-[#eff6ff] via-[#dbeafe] via-[#bfdbfe] to-[#93c5fd] animate-slow-pan-gradient';
      case 'ocean': return 'bg-gradient-to-br from-[#083344] via-[#155e75] via-[#0e7490] via-[#083344] to-[#020617] animate-slow-pan-gradient';
      case 'mountain': return 'bg-gradient-to-br from-[#0f172a] via-[#334155] via-[#475569] to-[#0f172a] animate-slow-pan-gradient';
      case 'clouds': return 'bg-gradient-to-br from-[#fee2e2] via-[#e0e7ff] via-[#fae8ff] to-[#f3e8ff] animate-slow-pan-gradient';
      case 'vintage': return 'bg-[#f4ebe1]';
      case 'watercolor': return 'bg-gradient-to-tr from-[#fecdd3] via-[#ffedd5] via-[#dbeafe] to-[#fcf6bd] animate-slow-pan-gradient';
      case 'pastel': return 'bg-gradient-to-br from-[#fbf8cc] via-[#fde2e4] via-[#ffcad4] via-[#b3e5fc] to-[#e8e8e4] animate-slow-pan-gradient';
      case 'golden': return 'bg-gradient-to-br from-[#fef08a] via-[#fde047] via-[#ca8a04] to-[#713f12] animate-slow-pan-gradient';
      case 'cherry': return 'bg-gradient-to-br from-[#fff1f2] via-[#ffe4e6] to-[#fecdd3] animate-slow-pan-gradient';
      case 'butterfly': return 'bg-gradient-to-br from-[#f0fdf4] via-[#dcfce7] via-[#bbf7d0] to-[#86efac] animate-slow-pan-gradient';
      case 'fireflies': return 'bg-gradient-to-b from-[#020617] via-[#052e16] to-[#020617] animate-slow-pan-gradient';
      case 'minimal': return 'bg-slate-50';
      case 'pink': return 'bg-gradient-to-br from-[#fff1f2] via-[#ffe4e6] to-[#ffd1d7] animate-slow-pan-gradient';
      
      default: return 'bg-black';
    }
  };

  const isLightTheme = ['sakura', 'lavender', 'winter', 'clouds', 'vintage', 'watercolor', 'pastel', 'cherry', 'butterfly', 'minimal', 'pink'].includes(settings.appTheme);

  useEffect(() => {
    const pwd = localStorage.getItem('app_password');
    if (pwd) {
      setSavedPassword(pwd);
    } else {
      setIsAuthenticated(true);
    }
  }, []);

  const themes = [
    
    { 
      id: 'constellation', 
      title: 'The Night Sky', 
      description: 'Connect the stars to reveal memories',
      icon: Sparkles,
      colorClass: 'bg-indigo-950/40 hover:bg-indigo-900/60 border border-indigo-400/80 shadow-[0_0_20px_rgba(99,102,241,0.5),inset_0_0_15px_rgba(99,102,241,0.2)] hover:shadow-[0_0_40px_rgba(99,102,241,0.9),inset_0_0_25px_rgba(99,102,241,0.5)] active:bg-indigo-800/60 active:border-indigo-300',
      titleColor: 'text-indigo-100 group-hover:text-white group-hover:drop-shadow-[0_0_10px_rgba(165,180,252,1)]',
      iconColor: 'text-indigo-300 group-hover:text-indigo-200 group-hover:scale-110 group-hover:rotate-12 drop-shadow-[0_0_10px_rgba(99,102,241,0.8)] group-hover:drop-shadow-[0_0_15px_rgba(129,140,248,1)]',
      glowColor: 'from-indigo-500/30 to-transparent'
    },
    { 
      id: 'tree', 
      title: 'Infinite Sky', 
      description: 'Balloons carrying memories to the sky',
      icon: Cloud,
      colorClass: 'bg-sky-950/40 hover:bg-sky-900/60 border border-sky-400/80 shadow-[0_0_20px_rgba(14,165,233,0.5),inset_0_0_15px_rgba(14,165,233,0.2)] hover:shadow-[0_0_40px_rgba(14,165,233,0.9),inset_0_0_25px_rgba(14,165,233,0.5)] active:bg-sky-800/60 active:border-sky-300',
      titleColor: 'text-sky-100 group-hover:text-white group-hover:drop-shadow-[0_0_10px_rgba(186,230,253,1)]',
      iconColor: 'text-sky-300 group-hover:text-sky-200 group-hover:scale-110 drop-shadow-[0_0_10px_rgba(14,165,233,0.8)] group-hover:drop-shadow-[0_0_15px_rgba(56,189,248,1)]',
      glowColor: 'from-sky-500/30 to-transparent'
    },
    { 
      id: 'lanterns', 
      title: 'Floating Lanterns', 
      description: 'Catch a lantern to see a cherished moment',
      icon: Flame,
      colorClass: 'bg-amber-950/40 hover:bg-amber-900/60 border border-amber-400/80 shadow-[0_0_20px_rgba(245,158,11,0.5),inset_0_0_15px_rgba(245,158,11,0.2)] hover:shadow-[0_0_40px_rgba(245,158,11,0.9),inset_0_0_25px_rgba(245,158,11,0.5)] active:bg-amber-800/60 active:border-amber-300',
      titleColor: 'text-amber-100 group-hover:text-white group-hover:drop-shadow-[0_0_10px_rgba(253,230,138,1)]',
      iconColor: 'text-amber-300 group-hover:text-amber-200 group-hover:scale-110 group-hover:animate-pulse drop-shadow-[0_0_10px_rgba(245,158,11,0.8)] group-hover:drop-shadow-[0_0_15px_rgba(251,191,36,1)]',
      glowColor: 'from-amber-500/30 to-transparent'
    },
    { 
      id: 'scrapbook', 
      title: 'Interactive Scrapbook', 
      description: 'Turn the pages of favorite times',
      icon: BookOpen,
      colorClass: 'bg-rose-950/40 hover:bg-rose-900/60 border border-rose-400/80 shadow-[0_0_20px_rgba(244,63,94,0.5),inset_0_0_15px_rgba(244,63,94,0.2)] hover:shadow-[0_0_40px_rgba(244,63,94,0.9),inset_0_0_25px_rgba(244,63,94,0.5)] active:bg-rose-800/60 active:border-rose-300',
      titleColor: 'text-rose-100 group-hover:text-white group-hover:drop-shadow-[0_0_10px_rgba(254,205,211,1)]',
      iconColor: 'text-rose-300 group-hover:text-rose-200 group-hover:scale-110 group-hover:-rotate-3 drop-shadow-[0_0_10px_rgba(244,63,94,0.8)] group-hover:drop-shadow-[0_0_15px_rgba(251,113,133,1)]',
      glowColor: 'from-rose-500/30 to-transparent'
    },
    { 
      id: 'garden', 
      title: 'The Memory Garden', 
      description: 'Magical stars sparkle among different blooming flowers',
      icon: Flower2,
      colorClass: 'bg-fuchsia-950/40 hover:bg-fuchsia-900/60 border border-fuchsia-400/80 shadow-[0_0_20px_rgba(217,70,239,0.5),inset_0_0_15px_rgba(217,70,239,0.2)] hover:shadow-[0_0_40px_rgba(217,70,239,0.9),inset_0_0_25px_rgba(217,70,239,0.5)] active:bg-fuchsia-800/60 active:border-fuchsia-300',
      titleColor: 'text-fuchsia-100 group-hover:text-white group-hover:drop-shadow-[0_0_10px_rgba(250,204,251,1)]',
      iconColor: 'text-fuchsia-300 group-hover:text-fuchsia-200 group-hover:scale-110 group-hover:rotate-45 drop-shadow-[0_0_10px_rgba(217,70,239,0.8)] group-hover:drop-shadow-[0_0_15px_rgba(232,121,249,1)]',
      glowColor: 'from-fuchsia-500/30 to-transparent'
    },
    { 
      id: 'apology', 
      title: 'The Core Message', 
      description: 'A heartfelt letter just for you',
      icon: Heart,
      colorClass: 'bg-violet-950/40 hover:bg-violet-900/60 border border-violet-400/80 shadow-[0_0_20px_rgba(139,92,246,0.5),inset_0_0_15px_rgba(139,92,246,0.2)] hover:shadow-[0_0_40px_rgba(139,92,246,0.9),inset_0_0_25px_rgba(139,92,246,0.5)] active:bg-violet-800/60 active:border-violet-300',
      titleColor: 'text-violet-100 group-hover:text-white group-hover:drop-shadow-[0_0_10px_rgba(221,214,254,1)]',
      iconColor: 'text-violet-300 group-hover:text-violet-200 group-hover:scale-115 drop-shadow-[0_0_10px_rgba(139,92,246,0.8)] group-hover:drop-shadow-[0_0_15px_rgba(167,139,250,1)]',
      glowColor: 'from-violet-500/30 to-transparent'
    },
  ];

  if (!isAuthenticated && savedPassword) {
    return <LoginScreen savedPassword={savedPassword} onLogin={() => setIsAuthenticated(true)} />;
  }

  return (
    <div 
      className={`relative min-h-screen font-sans overflow-x-hidden selection:bg-rose-500/30 flex flex-col transition-colors duration-500 ${getThemeClasses(settings.appTheme)} ${isLightTheme ? 'text-slate-900' : 'text-white'}`}
      style={settings.appTheme === 'custom' ? { backgroundColor: settings.customColor || '#1f2937' } : undefined}
    >
      <ThemeEffects theme={settings.appTheme} />
      {settings.appTheme !== 'default' && settings.appTheme !== 'custom' && !isLightTheme && (
        <div className="fixed inset-0 bg-black/50 pointer-events-none z-0" />
      )}
      {isLightTheme && (
        <div className="fixed inset-0 bg-white/15 pointer-events-none z-0" />
      )}
      <AnimatePresence>
        {!hasEntered && <GrandEntrance onEnter={() => { setHasEntered(true); setIsAudioMuted(false); }} />}
      </AnimatePresence>

      {settings.atmosphere && <Atmosphere />}
      
      {hasEntered && settings.cursorButterflies && <CursorButterflies />}

      {/* Global Controls */}
      {currentSongUrl && !currentYoutubeUrl && (
        <audio 
          src={currentSongUrl}
          autoPlay={hasEntered}
          loop
          muted={isAudioMuted}
        />
      )}

      {/* YouTube Background Player */}
      {currentYoutubeUrl && getYoutubeId(currentYoutubeUrl) && (
        <iframe
          className="hidden pointer-events-none absolute w-1 h-1"
          width="1"
          height="1"
          src={`https://www.youtube.com/embed/${getYoutubeId(currentYoutubeUrl)}?autoplay=1&loop=1&playlist=${getYoutubeId(currentYoutubeUrl)}&mute=${isAudioMuted ? 1 : 0}`}
          allow="autoplay"
        />
      )}

      {hasEntered && (
        <>
          <SettingsMenu settings={settings} setSettings={setSettings} />
          
          <div className="fixed top-6 right-6 z-50 flex items-center gap-3">
            <button 
              onClick={() => setIsAudioMuted(!isAudioMuted)}
              className={`backdrop-blur-md p-3.5 rounded-full transition-all duration-150 border shadow-lg group hover:scale-105 active:scale-95 active:bg-rose-500/80 ${isLightTheme ? 'bg-white/70 hover:bg-white/90 text-slate-800 border-slate-300' : 'bg-black/20 hover:bg-black/40 text-white/90 border-white/10'}`}
            >
              {!isAudioMuted ? <Music size={22} className="text-amber-500" /> : <VolumeX size={22} className={isLightTheme ? 'text-slate-400' : 'text-white/60'} />}
            </button>
          </div>
        </>
      )}

      {/* Main Content Journey */}
      <main className={`relative z-10 w-full flex-1 flex flex-col transition-opacity duration-1000 ${hasEntered ? 'opacity-100' : 'opacity-0'}`}>
        <AnimatePresence>
          {!selectedTheme ? (
            <motion.section 
              key="menu"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15, ease: "easeOut" }}
              className="w-full min-h-screen flex flex-col items-center justify-center py-20 px-4 relative"
            >
              <div className="text-center mb-16 flex flex-col items-center">
                 <h1 
                   className="text-4xl sm:text-5xl md:text-7xl font-serif font-bold tracking-wider sm:tracking-widest mb-6 flex flex-wrap items-center justify-center gap-0 sm:gap-1 animate-neon-text"
                 >
                   {"FOR SHIKSHA".split("").map((char, index) => (
                     <motion.span
                       key={index}
                       initial={{ opacity: 0, display: 'none' }}
                       animate={{ opacity: 1, display: 'inline-block' }}
                       transition={{ delay: index * 0.12 + 0.5, duration: 0.05 }}
                     >
                       {char === " " ? "\u00A0" : char}
                     </motion.span>
                   ))}
                   <motion.span
                     animate={{ opacity: [1, 0, 1] }}
                     transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}
                     className={`inline-block w-[3px] h-[40px] md:h-[60px] ml-1 ${isLightTheme ? 'bg-stone-900' : 'bg-white/80 shadow-[0_0_10px_rgba(255,255,255,0.6)]'}`}
                   />
                 </h1>
                 <motion.p 
                   initial={{ opacity: 0 }}
                   animate={{ opacity: 1 }}
                   transition={{ duration: 1, delay: 0.5 }}
                   className={`text-base md:text-xl font-light tracking-[0.1em] md:tracking-[0.2em] uppercase text-center ${isLightTheme ? 'text-stone-600/80 font-medium' : 'text-indigo-200/80'}`}
                 >
                   Choose a path to explore memories
                 </motion.p>
              </div>

               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl w-full">
                {themes.map((theme, i) => {
                  const IconComponent = theme.icon;
                  return (
                    <motion.div
                      key={theme.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.1 + 0.8 }}
                      onClick={() => setSelectedTheme(theme.id)}
                      className={`group relative cursor-pointer backdrop-blur-md p-8 rounded-xl transition-all duration-300 hover:scale-105 hover:-translate-y-2 active:scale-95 active:-translate-y-0 active:duration-75 flex flex-col h-full ${theme.colorClass} ${isLightTheme ? 'border-slate-300 bg-white/65 shadow-md hover:bg-white/80' : 'bg-black/20'}`}
                    >
                      <div className={`absolute inset-0 bg-gradient-to-br ${theme.glowColor} opacity-0 group-hover:opacity-100 transition-opacity rounded-xl pointer-events-none`} />
                      
                      <div className="flex items-start justify-between mb-5">
                        <div className={`p-3 border rounded-xl backdrop-blur-sm shadow-inner ${isLightTheme ? 'bg-stone-100 border-stone-200' : 'bg-white/5 border-white/10'}`}>
                          <IconComponent className={`w-6 h-6 transition-all duration-300 ${theme.iconColor}`} />
                        </div>
                      </div>

                      <h3 className={`text-2xl font-serif mb-3 transition-colors ${isLightTheme ? 'text-stone-850 font-bold' : theme.titleColor}`}>
                        {theme.title}
                      </h3>
                      <p className={`font-light leading-relaxed flex-1 text-sm ${isLightTheme ? 'text-stone-600' : 'text-white/70'}`}>
                        {theme.description}
                      </p>
                    </motion.div>
                  );
                })}
              </div>
              
              <div className="mt-12 flex justify-center w-full">
                <span className={`text-xs md:text-sm font-medium tracking-widest uppercase ${isLightTheme ? 'text-stone-400' : 'text-white/30'}`}>
                  Made by Bhavesh
                </span>
              </div>
            </motion.section>
          ) : (
            <motion.section 
              key="theme-view"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              transition={{ duration: 0.15, ease: "easeOut" }}
              className="w-full min-h-screen relative flex flex-col pt-24 pb-12"
            >
              <button 
                onClick={() => setSelectedTheme(null)}
                className={`absolute top-6 left-6 md:left-12 z-50 flex items-center gap-2 transition-all duration-150 px-5 py-2.5 rounded-full border backdrop-blur-md group active:scale-95 active:bg-rose-500/80 active:border-rose-400 ${isLightTheme ? 'bg-white/70 hover:bg-white/90 text-stone-800 border-slate-300' : 'bg-black/20 hover:bg-black/40 text-white/60 hover:text-white border-white/10'}`}
              >
                <ArrowLeft size={18} className="transition-transform group-hover:-translate-x-1" />
                <span className="font-medium tracking-wide uppercase text-xs md:text-sm">Back to Menu</span>
              </button>

              {selectedTheme === 'constellation' && (
                <motion.div 
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.15, ease: "easeOut" }}
                  className="w-full h-full flex flex-col items-center justify-center flex-1"
                >
                  <div className="text-center z-20 pointer-events-none px-4 mb-6">
                    <h2 className="text-4xl md:text-5xl text-indigo-100/90 font-serif mb-2">The Night Sky</h2>
                  </div>
                  <Constellation />
                </motion.div>
              )}
              {selectedTheme === 'tree' && (
                <motion.div 
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.15, ease: "easeOut" }}
                  className="w-full h-full flex flex-col items-center justify-center flex-1"
                >
                  <MemoryTree />
                </motion.div>
              )}
              {selectedTheme === 'lanterns' && (
                <motion.div 
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.15, ease: "easeOut" }}
                  className="w-full h-full flex flex-col items-center justify-center flex-1 min-h-[70vh]"
                >
                  <Lanterns />
                </motion.div>
              )}
              {selectedTheme === 'garden' && (
                <motion.div 
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.15, ease: "easeOut" }}
                  className="w-full h-full flex flex-col items-center justify-center flex-1 min-h-[70vh]"
                >
                  <Garden />
                </motion.div>
              )}
              {selectedTheme === 'scrapbook' && (
                <motion.div 
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.15, ease: "easeOut" }}
                  className="w-full h-full flex flex-col items-center justify-center flex-1"
                >
                  <Scrapbook />
                </motion.div>
              )}
              {selectedTheme === 'apology' && (
                <motion.div 
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.15, ease: "easeOut" }}
                  className="w-full h-full flex flex-col items-center justify-center flex-1"
                >
                  <div className="text-center mb-10 px-4">
                    <h2 className="text-4xl md:text-5xl text-rose-100/90 font-serif mb-4">The Core Message</h2>
                    <p className="text-rose-200/60 font-light italic text-lg">I needed you to see how much you mean to me first.</p>
                  </div>
                  <ApologyLetter />
                </motion.div>
              )}
            </motion.section>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
