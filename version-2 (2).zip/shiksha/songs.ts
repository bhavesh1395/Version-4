export const PLAYLIST: { id: string; title: string; url: string }[] = [];
