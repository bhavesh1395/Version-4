#!/bin/bash
cat > temp.tsx << 'INNEREOF'
  // Premium, Natural Speech Synthesis Controller
  useEffect(() => {
    if (typeof window === 'undefined' || !window.speechSynthesis) {
      if (isPlaying) setIsPlaying(false);
      return;
    }

    if (!isPlaying) {
      try {
        window.speechSynthesis.cancel();
      } catch (e) {
        console.error("Speech synthesis cancel error", e);
      }
      return;
    }

    // Filter out emojis for clear narration
    const narrationText = apologyText.replace(/❤️/g, '').trim();
    let utterance: SpeechSynthesisUtterance;
    try {
      utterance = new SpeechSynthesisUtterance(narrationText);
      speechRef.current = utterance;
    } catch (e) {
      console.error("Speech synthesis initialization error", e);
      setIsPlaying(false);
      return;
    }

    // Retrieve high quality natural or female voices
    const loadVoicesAndSpeak = () => {
      try {
        const voices = window.speechSynthesis.getVoices() || [];
        
        // Select the finest premium natural female voices
        const preferredVoice = voices.find(v => 
          (v.name.includes('Google') && v.name.includes('US English') && v.name.toLowerCase().includes('female')) ||
          (v.name.includes('Natural') && v.lang.startsWith('en')) ||
          v.name.includes('Samantha') ||
          v.name.includes('Zira') ||
          v.name.includes('Google US English') ||
          v.name.toLowerCase().includes('female')
        ) || voices.find(v => v.lang.startsWith('en')) || voices[0];

        if (preferredVoice) {
          utterance.voice = preferredVoice;
        }

        // Emotional tender pacing configuration
        utterance.rate = 0.82;   // elegant slow pacing
        utterance.pitch = 1.05;  // warm bright tone
        utterance.volume = 1.0;  // full audibility

        utterance.onend = () => setIsPlaying(false);
        utterance.onerror = () => setIsPlaying(false);
        
        window.speechSynthesis.speak(utterance);
      } catch (e) {
        console.error("Speech synthesis error", e);
        setIsPlaying(false);
      }
    };

    // Chrome/Safari voice lazy loading guard
    try {
      if (window.speechSynthesis.getVoices().length > 0) {
        loadVoicesAndSpeak();
      } else {
        window.speechSynthesis.onvoiceschanged = loadVoicesAndSpeak;
      }
    } catch (e) {
      console.error("Speech synthesis voices error", e);
      setIsPlaying(false);
    }

    return () => {
      try {
        if (window.speechSynthesis) {
          window.speechSynthesis.cancel();
        }
      } catch (e) {}
    };
  }, [isPlaying]);
INNEREOF

awk '
/^\s*\/\/ Premium, Natural Speech Synthesis Controller/ {
  in_block = 1
  while ((getline line < "temp.tsx") > 0) {
    print line
  }
  next
}
in_block {
  if ($0 ~ /^\s*return \(/) {
    in_block = 0
    print $0
  }
  next
}
{ print }
' shiksha/components/ApologyLetter.tsx > temp2.tsx

mv temp2.tsx shiksha/components/ApologyLetter.tsx
