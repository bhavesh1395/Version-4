#!/bin/bash
sed -i 's/transition={{ duration: 0.15 }}/transition={{ duration: 0.15, ease: "easeOut" }}/g' shiksha/components/Lanterns.tsx
sed -i 's/transition={{ duration: 0.15 }}/transition={{ duration: 0.15, ease: "easeOut" }}/g' shiksha/components/MemoryTree.tsx
sed -i 's/transition={{ duration: 0.15 }}/transition={{ duration: 0.15, ease: "easeOut" }}/g' shiksha/components/Constellation.tsx
sed -i 's/transition={{ duration: 0.15 }}/transition={{ duration: 0.15, ease: "easeOut" }}/g' shiksha/components/Garden.tsx
