#!/bin/bash
sed -i 's/body {/\* {/g' shiksha/index.css
sed -i 's/user-select: none;/user-select: none !important;/g' shiksha/index.css
sed -i 's/-webkit-user-select: none;/-webkit-user-select: none !important;/g' shiksha/index.css
sed -i 's/input, textarea {/input, textarea, select {/g' shiksha/index.css
sed -i 's/user-select: auto;/user-select: auto !important;/g' shiksha/index.css
sed -i 's/-webkit-user-select: auto;/-webkit-user-select: auto !important;/g' shiksha/index.css
