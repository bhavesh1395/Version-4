#!/bin/bash
cat << 'INNER' > shiksha/components/ApologyLetter.tsx
import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, Play, Pause, Loader2 } from 'lucide-react';

const apologyText = "Dear Shiksha,\n\nI am so incredibly sorry for how I acted. You mean the world to me, and seeing you upset breaks my heart. I was stupid, and I promise to do better.\n\nLooking back at all these memories reminds me of how lucky I am to have you in my life. This friendship is too beautiful to let my foolishness ruin it.\n\nPlease forgive me. ❤️\n\nYour Bhavesh";

const narrationText = "Dear Shiksha. ... I am so incredibly sorry ... for how I acted. ... You mean the world to me. ... And seeing you upset, breaks my heart. ... I was stupid. And I promise to do better. ... Looking back at all these memories ... reminds me of how lucky I am ... to have you in my life. ... This friendship ... is too beautiful ... to let my foolishness ruin it. ... Please, ... forgive me. ... Your Bhavesh.";

export function ApologyLetter() {
  const [isOpen, setIsOpen] = useState(false);
  const [displayedText, setDisplayedText] = useState("");
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoadingAudio, setIsLoadingAudio] = useState(false);
  
  const textRef = useRef<HTMLDivElement>(null);
  const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);

  useEffect(() => {
    if (isOpen) {
      let i = 0;
      setDisplayedText("");
      const interval = setInterval(() => {
        setDisplayedText(apologyText.slice(0, i));
        i++;
        if (textRef.current) {
           textRef.current.scrollTop = textRef.current.scrollHeight;
        }
        if (i > apologyText.length) {
          clearInterval(interval);
        }
      }, 40);
      return () => clearInterval(interval);
    }
  }, [isOpen]);

  const toggleAudio = async () => {
    if (isPlaying) {
      if (audioSourceRef.current) {
        audioSourceRef.current.stop();
        audioSourceRef.current.disconnect();
      }
      setIsPlaying(false);
      return;
    }

    setIsLoadingAudio(true);
    try {
      const response = await fetch('/api/tts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ text: narrationText })
      });
      
      const data = await response.json();
      if (data.audio) {
        const binary = atob(data.audio);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
          bytes[i] = binary.charCodeAt(i);
        }
        
        const int16Array = new Int16Array(bytes.buffer);
        
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        const audioCtx = new AudioContextClass({ sampleRate: 24000 });
        audioCtxRef.current = audioCtx;
        
        const audioBuffer = audioCtx.createBuffer(1, int16Array.length, 24000);
        const channelData = audioBuffer.getChannelData(0);
        
        for (let i = 0; i < int16Array.length; i++) {
            channelData[i] = int16Array[i] / 32768.0;
        }
        
        const source = audioCtx.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(audioCtx.destination);
        source.onended = () => setIsPlaying(false);
        source.start();
        
        audioSourceRef.current = source;
        setIsPlaying(true);
      } else {
         fallbackSpeech();
      }
    } catch (e) {
      console.error(e);
      fallbackSpeech();
    }
    setIsLoadingAudio(false);
  };

  const fallbackSpeech = () => {
    if (typeof window === 'undefined' || !window.speechSynthesis) {
      return;
    }
    let utterance = new SpeechSynthesisUtterance(narrationText);
    
    let voices = window.speechSynthesis.getVoices();
    const preferredVoice = voices.find(v => 
      (v.name.includes('Google') && v.name.includes('US English') && v.name.toLowerCase().includes('female')) ||
      (v.name.includes('Natural') && v.lang.startsWith('en')) ||
      v.name.includes('Samantha') ||
      v.name.includes('Zira') ||
      v.name.includes('Google US English') ||
      v.name.toLowerCase().includes('female')
    ) || voices.find(v => v.lang.startsWith('en')) || voices[0];
    
    if (preferredVoice) utterance.voice = preferredVoice;
    
    utterance.rate = 0.82;
    utterance.pitch = 1.05;
    utterance.volume = 1.0;
    utterance.onend = () => setIsPlaying(false);
    utterance.onerror = () => setIsPlaying(false);
    
    window.speechSynthesis.speak(utterance);
    setIsPlaying(true);
  };

  useEffect(() => {
    return () => {
      if (audioSourceRef.current) {
        try { audioSourceRef.current.stop(); } catch(e){}
      }
      try { window.speechSynthesis.cancel(); } catch (e) {}
    };
  }, []);

  return (
    <div className="w-full min-h-[80vh] flex flex-col items-center justify-center p-4 relative z-20">
      
      {!isOpen ? (
        <motion.div
          animate={{ y: [0, -15, 0] }}
          transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
          onClick={() => setIsOpen(true)}
          className="cursor-pointer group relative"
        >
          <div className="absolute text-center -top-16 left-1/2 -translate-x-1/2 w-full text-rose-200 font-serif italic text-lg opacity-0 group-hover:opacity-100 transition-opacity">
            A message for you...
          </div>
          
          <div className="absolute inset-0 bg-rose-500/40 blur-3xl rounded-full scale-150 group-hover:bg-rose-500/60 transition-colors duration-500" />
          
          <div className="relative bg-[#f1f5f9] w-72 md:w-80 h-48 md:h-56 rounded-lg shadow-2xl flex items-center justify-center overflow-hidden group-hover:scale-105 transition-transform duration-500">
             <div className="absolute inset-0 border-t-[40px] md:border-t-[50px] border-t-slate-300 border-x-[144px] md:border-x-[160px] border-x-transparent border-b-[96px] md:border-b-[112px] border-b-slate-200 opacity-90" />
             <div className="absolute text-rose-600 flex flex-col items-center justify-center drop-shadow-xl bg-rose-100 w-16 h-16 rounded-full border-2 border-rose-300 z-10">
                <Heart fill="currentColor" size={28} className="animate-pulse" />
             </div>
          </div>
        </motion.div>
      ) : (
        <motion.div 
          initial={{ opacity: 0, scale: 0.95, y: 50, rotateX: -20 }}
          animate={{ opacity: 1, scale: 1, y: 0, rotateX: 0 }}
          transition={{ type: "spring", damping: 15 }}
          className="bg-[#fcfaf8] w-full max-w-2xl p-8 md:p-14 rounded-sm shadow-[0_20px_50px_rgba(0,0,0,0.5)] text-slate-800 font-serif relative"
        >
          <div className="absolute top-6 right-6 opacity-10 pointer-events-none">
             <Heart size={120} fill="currentColor" className="text-rose-500" />
          </div>
          
          <div 
            ref={textRef}
            className="whitespace-pre-wrap text-[17px] md:text-xl leading-[1.8] md:leading-[2] min-h-[350px] z-10 relative text-slate-700 tracking-wide"
          >
            {displayedText}
            {displayedText.length < apologyText.length && (
              <span className="inline-block w-2 h-5 bg-rose-400 ml-1 animate-pulse align-middle" />
            )}
          </div>

          <AnimatePresence>
            {displayedText.length === apologyText.length && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1, duration: 1 }}
                className="mt-12 flex flex-col items-center border-t border-slate-200/60 pt-10"
              >
                 <p className="text-xs text-slate-400 mb-6 uppercase tracking-[0.2em] font-sans">A Personal Message</p>
                 <button
                   onClick={toggleAudio}
                   disabled={isLoadingAudio}
                   className="flex items-center gap-3 bg-slate-900 hover:bg-rose-600 disabled:bg-slate-400 text-white px-8 py-4 rounded-full shadow-lg transition-all duration-300 hover:scale-105 active:scale-95 group"
                 >
                    {isLoadingAudio ? (
                      <Loader2 size={20} className="animate-spin" />
                    ) : isPlaying ? (
                      <Pause size={20} fill="currentColor" />
                    ) : (
                      <Play size={20} fill="currentColor" className="ml-1" />
                    )}
                    <span className="font-sans font-medium tracking-wide">
                      {isLoadingAudio ? "Preparing Message..." : isPlaying ? "Pause Message" : "Play Voice Message"}
                    </span>
                 </button>
                 
                 {isPlaying && (
                    <motion.div 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="mt-6 flex gap-1 items-center h-8"
                    >
                      {[...Array(5)].map((_, i) => (
                        <motion.div
                          key={i}
                          className="w-1.5 bg-rose-400 rounded-full"
                          animate={{ height: ['4px', '24px', '4px'] }}
                          transition={{ repeat: Infinity, duration: 0.8, delay: i * 0.15 }}
                        />
                      ))}
                    </motion.div>
                 )}
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      )}
    </div>
  );
}
INNER
