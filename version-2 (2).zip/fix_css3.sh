#!/bin/bash
cat << 'INNEREOF' > shiksha/index.css
@import "tailwindcss";

@layer utilities {
  .animate-slow-pan {
    animation: slow-pan 60s ease-in-out infinite alternate;
  }
  .animate-slow-pan-gradient {
    animation: slow-pan-gradient 20s ease infinite;
    background-size: 400% 400%;
  }
  .animate-neon-text {
    background: linear-gradient(to right, #ff2a85, #8a2be2, #00e5ff, #39ff14, #ff2a85);
    background-size: 200% auto;
    color: transparent;
    -webkit-background-clip: text;
    background-clip: text;
    animation: neon-shine 4s linear infinite;
    filter: drop-shadow(0 0 8px rgba(255, 42, 133, 0.6)) drop-shadow(0 0 20px rgba(0, 229, 255, 0.4));
  }
}

@keyframes neon-shine {
  to {
    background-position: 200% center;
  }
}

@keyframes slow-pan {
  0% {
    background-position: 0% 50%;
    background-size: 110% auto;
  }
  50% {
    background-position: 100% 50%;
    background-size: 115% auto;
  }
  100% {
    background-position: 0% 50%;
    background-size: 110% auto;
  }
}

@keyframes slow-pan-gradient {
  0% {
    background-position: 0% 50%;
  }
  50% {
    background-position: 100% 50%;
  }
  100% {
    background-position: 0% 50%;
  }
}

@keyframes fall {
  0% {
    transform: translateY(-10vh) translateX(0);
  }
  100% {
    transform: translateY(110vh) translateX(20px) rotate(360deg);
  }
}

@keyframes fall-sway {
  0% {
    transform: translateY(-10vh) translateX(0) rotate(0deg);
  }
  33% {
    transform: translateY(30vh) translateX(30px) rotate(120deg);
  }
  66% {
    transform: translateY(70vh) translateX(-20px) rotate(240deg);
  }
  100% {
    transform: translateY(110vh) translateX(10px) rotate(360deg);
  }
}

@keyframes rain-fall {
  0% {
    transform: translateY(-10vh) translateX(0) scaleY(1);
    opacity: 1;
  }
  100% {
    transform: translateY(110vh) translateX(-5px) scaleY(1.5);
    opacity: 0.2;
  }
}

@keyframes float-up {
  0% {
    transform: translateY(10vh) scale(1);
    opacity: 0;
  }
  10% {
    opacity: 1;
  }
  90% {
    opacity: 1;
  }
  100% {
    transform: translateY(-110vh) scale(1.5);
    opacity: 0;
  }
}

@keyframes firefly-float {
  0% {
    transform: translate(0, 0) scale(0.8);
    opacity: 0;
  }
  25% {
    opacity: 1;
    transform: translate(20px, -20px) scale(1.2);
  }
  50% {
    transform: translate(-10px, -40px) scale(0.9);
    opacity: 0.8;
  }
  75% {
    transform: translate(30px, -60px) scale(1.1);
    opacity: 1;
  }
  100% {
    transform: translate(0, -80px) scale(0.8);
    opacity: 0;
  }
}

@keyframes pulse-star {
  0%, 100% {
    opacity: 0.2;
    transform: scale(0.8);
  }
  50% {
    opacity: 1;
    transform: scale(1.2);
  }
}

@keyframes rise-up {
  0% { transform: translateY(120vh); }
  100% { transform: translateY(-150vh); }
}

@keyframes rise-up-sway {
  0% { transform: translateY(120vh) translateX(0) rotate(-5deg); }
  50% { transform: translateY(-15vh) translateX(20px) rotate(5deg); }
  100% { transform: translateY(-150vh) translateX(-10px) rotate(-5deg); }
}

@keyframes shimmer {
  100% { transform: translateX(100%); }
}

@keyframes shiksha-fall {
  0% {
    transform: translateY(-20vh) translateX(0);
  }
  25% {
    transform: translateY(15vh) translateX(30px);
  }
  50% {
    transform: translateY(50vh) translateX(-20px);
  }
  75% {
    transform: translateY(85vh) translateX(15px);
  }
  100% {
    transform: translateY(120vh) translateX(0);
  }
}

* {
  user-select: none !important;
  -webkit-user-select: none !important;
}

input, textarea, select {
  user-select: auto !important;
  -webkit-user-select: auto !important;
}
INNEREOF
