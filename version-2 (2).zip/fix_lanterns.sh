#!/bin/bash
sed -i 's/exit={{ opacity: 0, scale: 0.9 }}/exit={{ opacity: 0, scale: 0.9 }}\n            transition={{ duration: 0.15 }}/g' shiksha/components/Lanterns.tsx
