#!/bin/bash
sed -i 's/exit={{ opacity: 0 }}/exit={{ opacity: 0 }}\n            transition={{ duration: 0.15 }}/g' shiksha/components/Garden.tsx
sed -i 's/exit={{ scale: 0.9, y: 20 }}/exit={{ scale: 0.9, y: 20 }}\n              transition={{ duration: 0.15 }}/g' shiksha/components/Garden.tsx
