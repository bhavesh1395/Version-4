sed -i 's/const \[isLoadingAudio, setIsLoadingAudio\] = useState\(false\);//g' shiksha/components/ApologyLetter.tsx
sed -i 's/disabled={isLoadingAudio}//g' shiksha/components/ApologyLetter.tsx
