#!/bin/bash
awk '
/^-e \*/ { exit }
{ print }
' shiksha/index.css > temp.css

cat << 'INNEREOF' >> temp.css

* {
  user-select: none !important;
  -webkit-user-select: none !important;
}
input, textarea, select {
  user-select: auto !important;
  -webkit-user-select: auto !important;
}
INNEREOF

mv temp.css shiksha/index.css
